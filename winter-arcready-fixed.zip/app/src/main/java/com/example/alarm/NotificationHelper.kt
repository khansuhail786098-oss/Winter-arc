package com.example.alarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.receiver.AlarmReceiver

object NotificationHelper {
    const val CHANNEL_REMINDERS = "channel_reminders"
    const val CHANNEL_HIGH_ALERT = "channel_high_alert"
    const val CHANNEL_CRITICAL_ALARMS = "channel_critical_alarms"
    const val CHANNEL_DAILY_BRIEFING = "channel_daily_briefing"
    const val CHANNEL_NIGHT_REVIEW = "channel_night_review"
    const val CHANNEL_STUDY = "channel_study"
    const val CHANNEL_WORKOUT = "channel_workout"

    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val alarmSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)

            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .build()

            val alarmAudioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(AudioAttributes.USAGE_ALARM)
                .build()

            val channels = listOf(
                NotificationChannel(
                    CHANNEL_REMINDERS,
                    "Task Reminders",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "Normal task and habit reminders"
                    enableVibration(true)
                },
                NotificationChannel(
                    CHANNEL_HIGH_ALERT,
                    "High Alert Escalation",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Escalating priority alerts for critical commitments"
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 500, 200, 500)
                },
                NotificationChannel(
                    CHANNEL_CRITICAL_ALARMS,
                    "Critical Alarms",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Audible alarms for crucial tasks and wake-up schedules"
                    setSound(alarmSoundUri, alarmAudioAttributes)
                    enableVibration(true)
                    vibrationPattern = longArrayOf(0, 800, 400, 800, 400, 800)
                },
                NotificationChannel(
                    CHANNEL_DAILY_BRIEFING,
                    "Morning Briefing",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "Daily targets and morning focus directives"
                },
                NotificationChannel(
                    CHANNEL_NIGHT_REVIEW,
                    "Nightly Review",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "Evening review and next-day planning"
                },
                NotificationChannel(
                    CHANNEL_STUDY,
                    "Study & Revision Sessions",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "Spaced repetition revision and study blocks"
                },
                NotificationChannel(
                    CHANNEL_WORKOUT,
                    "Workout Notifications",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "Workout schedule and rest timer notifications"
                }
            )

            channels.forEach { notificationManager.createNotificationChannel(it) }
        }
    }

    fun showTaskAlarmNotification(
        context: Context,
        taskId: Long,
        taskTitle: String,
        taskCategory: String,
        stage: Int,
        isCritical: Boolean
    ) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val channelId = when {
            isCritical || stage >= 3 -> CHANNEL_CRITICAL_ALARMS
            stage >= 2 -> CHANNEL_HIGH_ALERT
            else -> CHANNEL_REMINDERS
        }

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("open_screen", "today")
            putExtra("task_id", taskId)
        }
        val openPendingIntent = PendingIntent.getActivity(
            context,
            taskId.toInt(),
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val completeIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = "com.aistudio.winterarc.ACTION_COMPLETE_TASK"
            putExtra("task_id", taskId)
        }
        val completePendingIntent = PendingIntent.getBroadcast(
            context,
            (taskId + 10000).toInt(),
            completeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val snoozeIntent = Intent(context, AlarmReceiver::class.java).apply {
            action = "com.aistudio.winterarc.ACTION_SNOOZE_ALARM"
            putExtra("task_id", taskId)
        }
        val snoozePendingIntent = PendingIntent.getBroadcast(
            context,
            (taskId + 20000).toInt(),
            snoozeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stageText = when (stage) {
            1 -> "STAGE 1: Commitment Scheduled"
            2 -> "STAGE 2: Persistent Reminder"
            3 -> "STAGE 3: High-Priority Alert"
            4 -> "STAGE 4: Audible Alarm Active"
            5 -> "STAGE 5: Attention Required — Near Miss"
            else -> "Execute Commitment"
        }

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("WINTER ARC • $taskTitle")
            .setContentText("[$taskCategory] $stageText")
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("[$taskCategory] $stageText\nExecute now without compromise. Stay on track with your Winter Arc discipline.")
            )
            .setPriority(if (isCritical || stage >= 3) NotificationCompat.PRIORITY_MAX else NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(openPendingIntent)
            .setAutoCancel(true)
            .addAction(android.R.drawable.checkbox_on_background, "Complete", completePendingIntent)
            .addAction(android.R.drawable.ic_popup_reminder, "Snooze 10m", snoozePendingIntent)
            .build()

        notificationManager.notify(taskId.toInt(), notification)
    }
}
