package com.example.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.data.local.entity.TaskEntity
import com.example.domain.DateUtils
import com.example.receiver.AlarmReceiver
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object AlarmScheduler {
    private const val TAG = "AlarmScheduler"

    fun canScheduleExactAlarms(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }
    }

    fun scheduleTaskAlarm(context: Context, task: TaskEntity) {
        if (!task.isAlarmEnabled || task.plannedDate.isBlank() || task.startTime.isBlank()) {
            return
        }

        try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val triggerTime = calculateTriggerTime(task.plannedDate, task.startTime)

            // If time is already passed by more than 1 minute, don't schedule
            if (triggerTime <= System.currentTimeMillis() - 60_000) {
                return
            }

            val intent = Intent(context, AlarmReceiver::class.java).apply {
                action = "com.aistudio.winterarc.ACTION_TASK_ALARM"
                putExtra("task_id", task.id)
                putExtra("task_title", task.title)
                putExtra("task_category", task.category.name)
                putExtra("is_critical", task.priority.name == "CRITICAL")
                putExtra("alarm_stage", 1)
            }

            val pendingIntent = PendingIntent.getBroadcast(
                context,
                task.id.toInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
            }
            Log.d(TAG, "Scheduled alarm for task ${task.id} at $triggerTime")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to schedule alarm for task ${task.id}: ${e.message}")
        }
    }

    fun cancelTaskAlarm(context: Context, taskId: Long) {
        try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val intent = Intent(context, AlarmReceiver::class.java).apply {
                action = "com.aistudio.winterarc.ACTION_TASK_ALARM"
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context,
                taskId.toInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            alarmManager.cancel(pendingIntent)
            Log.d(TAG, "Cancelled alarm for task $taskId")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to cancel alarm for task $taskId: ${e.message}")
        }
    }

    fun scheduleSnoozeAlarm(context: Context, taskId: Long, taskTitle: String, category: String, isCritical: Boolean) {
        try {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val triggerTime = System.currentTimeMillis() + (10 * 60 * 1000) // 10 minutes

            val intent = Intent(context, AlarmReceiver::class.java).apply {
                action = "com.aistudio.winterarc.ACTION_TASK_ALARM"
                putExtra("task_id", taskId)
                putExtra("task_title", taskTitle)
                putExtra("task_category", category)
                putExtra("is_critical", isCritical)
                putExtra("alarm_stage", 2)
            }

            val pendingIntent = PendingIntent.getBroadcast(
                context,
                taskId.toInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to schedule snooze alarm: ${e.message}")
        }
    }

    private fun calculateTriggerTime(dateStr: String, timeStr: String): Long {
        val format = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        val date = format.parse("$dateStr $timeStr") ?: return System.currentTimeMillis()
        return date.time
    }
}
