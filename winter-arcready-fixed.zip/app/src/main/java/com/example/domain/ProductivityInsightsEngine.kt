package com.example.domain

import com.example.data.local.entity.DailyScoreEntity
import com.example.data.local.entity.StudySessionEntity
import com.example.data.local.entity.TaskEntity
import com.example.data.local.entity.TaskStatus

data class ProductivityInsight(
    val title: String,
    val description: String,
    val iconName: String,
    val type: InsightType
)

enum class InsightType {
    POSITIVE, ATTENTION, WARNING, INFO
}

object ProductivityInsightsEngine {

    fun generateInsights(
        allTasks: List<TaskEntity>,
        recentScores: List<DailyScoreEntity>,
        studySessions: List<StudySessionEntity>
    ): List<ProductivityInsight> {
        val insights = mutableListOf<ProductivityInsight>()

        // 1. Anti-procrastination: Rescheduled Tasks detection
        val heavilyRescheduled = allTasks.filter { it.rescheduledCount >= 2 && it.status != TaskStatus.COMPLETED }
        if (heavilyRescheduled.isNotEmpty()) {
            val mostRescheduled = heavilyRescheduled.maxByOrNull { it.rescheduledCount }
            if (mostRescheduled != null) {
                insights.add(
                    ProductivityInsight(
                        title = "Avoidance Detected: \"${mostRescheduled.title}\"",
                        description = "This task has been rescheduled ${mostRescheduled.rescheduledCount} times. Consider breaking it down or assigning a smaller 30-minute block.",
                        iconName = "warning",
                        type = InsightType.WARNING
                    )
                )
            }
        }

        // 2. Study consistency analysis
        if (studySessions.isNotEmpty()) {
            val totalMinutes = studySessions.sumOf { it.durationMinutes }
            val totalHours = totalMinutes / 60
            insights.add(
                ProductivityInsight(
                    title = "Deep Study Accumulation",
                    description = "You have logged $totalHours total hours across ${studySessions.size} structured study sessions.",
                    iconName = "school",
                    type = InsightType.POSITIVE
                )
            )
        }

        // 3. Score trend analysis
        if (recentScores.size >= 3) {
            val avgScore = recentScores.map { it.totalScore }.average().toInt()
            val missedTotal = recentScores.sumOf { it.tasksMissed }
            if (avgScore >= 80) {
                insights.add(
                    ProductivityInsight(
                        title = "High Discipline Arc Performance",
                        description = "Your recent score average is $avgScore%. You are executing at peak Winter Arc capacity.",
                        iconName = "military_tech",
                        type = InsightType.POSITIVE
                    )
                )
            } else if (missedTotal > 2) {
                insights.add(
                    ProductivityInsight(
                        title = "Commitment Leakage: $missedTotal Missed Tasks",
                        description = "You have missed $missedTotal planned commitments recently. Tighten your schedule to realistic time blocks.",
                        iconName = "error_outline",
                        type = InsightType.ATTENTION
                    )
                )
            }
        }

        // 4. Task completion rate
        val completedCount = allTasks.count { it.status == TaskStatus.COMPLETED }
        if (allTasks.isNotEmpty() && completedCount > 0) {
            val rate = (completedCount.toFloat() / allTasks.size.toFloat() * 100).toInt()
            insights.add(
                ProductivityInsight(
                    title = "Execution Rate: $rate%",
                    description = "Completed $completedCount out of ${allTasks.size} historical commitments logged.",
                    iconName = "check_circle",
                    type = InsightType.INFO
                )
            )
        }

        if (insights.isEmpty()) {
            insights.add(
                ProductivityInsight(
                    title = "Winter Arc Protocol Active",
                    description = "Plan your daily commitments, execute each block without hesitation, and review every night.",
                    iconName = "ac_unit",
                    type = InsightType.INFO
                )
            )
        }

        return insights
    }
}
