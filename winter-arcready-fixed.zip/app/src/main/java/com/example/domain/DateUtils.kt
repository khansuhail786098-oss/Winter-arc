package com.example.domain

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateUtils {
    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val displayDateFormat = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault())
    private val shortDisplayDateFormat = SimpleDateFormat("MMM d", Locale.getDefault())

    fun todayString(): String = dateFormat.format(Date())

    fun nowTimeString(): String = timeFormat.format(Date())

    fun formatDate(timestamp: Long): String = dateFormat.format(Date(timestamp))

    fun formatDisplayDate(dateString: String): String {
        return try {
            val date = dateFormat.parse(dateString) ?: Date()
            displayDateFormat.format(date)
        } catch (e: Exception) {
            dateString
        }
    }

    fun formatShortDisplayDate(dateString: String): String {
        return try {
            val date = dateFormat.parse(dateString) ?: Date()
            shortDisplayDateFormat.format(date)
        } catch (e: Exception) {
            dateString
        }
    }

    fun getDayOffset(dateString: String, offsetDays: Int): String {
        return try {
            val cal = Calendar.getInstance()
            val date = dateFormat.parse(dateString) ?: Date()
            cal.time = date
            cal.add(Calendar.DAY_OF_YEAR, offsetDays)
            dateFormat.format(cal.time)
        } catch (e: Exception) {
            todayString()
        }
    }

    fun calculateDaysBetween(startDateStr: String, endDateStr: String): Long {
        return try {
            val start = dateFormat.parse(startDateStr)?.time ?: 0L
            val end = dateFormat.parse(endDateStr)?.time ?: 0L
            val diff = (end - start) / (1000 * 60 * 60 * 24)
            maxOf(0L, diff)
        } catch (e: Exception) {
            0L
        }
    }

    fun calculateArcDayNumber(startDateStr: String): Int {
        if (startDateStr.isBlank()) return 1
        return try {
            val start = dateFormat.parse(startDateStr) ?: Date()
            val today = dateFormat.parse(todayString()) ?: Date()
            val diff = ((today.time - start.time) / (1000 * 60 * 60 * 24)).toInt() + 1
            maxOf(1, diff)
        } catch (e: Exception) {
            1
        }
    }

    fun formatMinutesToHoursAndMinutes(totalMinutes: Int): String {
        if (totalMinutes <= 0) return "0m"
        val hours = totalMinutes / 60
        val mins = totalMinutes % 60
        return when {
            hours > 0 && mins > 0 -> "${hours}h ${mins}m"
            hours > 0 -> "${hours}h"
            else -> "${mins}m"
        }
    }

    fun parseTimeToMinutes(timeStr: String): Int {
        if (!timeStr.contains(":")) return 0
        val parts = timeStr.split(":")
        val h = parts.getOrNull(0)?.toIntOrNull() ?: 0
        val m = parts.getOrNull(1)?.toIntOrNull() ?: 0
        return h * 60 + m
    }

    fun getRemainingDaysUntil(targetDateStr: String): Int {
        if (targetDateStr.isBlank()) return 0
        return try {
            val target = dateFormat.parse(targetDateStr) ?: return 0
            val today = dateFormat.parse(todayString()) ?: return 0
            val diff = ((target.time - today.time) / (1000 * 60 * 60 * 24)).toInt()
            maxOf(0, diff)
        } catch (e: Exception) {
            0
        }
    }

    fun getPastWeekDates(endDate: String = todayString()): List<String> {
        val list = mutableListOf<String>()
        for (i in 6 downTo 0) {
            list.add(getDayOffset(endDate, -i))
        }
        return list
    }
}
