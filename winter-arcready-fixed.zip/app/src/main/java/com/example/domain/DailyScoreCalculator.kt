package com.example.domain

import com.example.data.local.entity.DailyScoreEntity
import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.HabitLogEntity
import com.example.data.local.entity.TaskCategory
import com.example.data.local.entity.TaskEntity
import com.example.data.local.entity.TaskStatus
import com.example.data.local.entity.UserProfileEntity

object DailyScoreCalculator {

    /**
     * Calculates a rigorous, non-inflated score from 0 to 100 based on user targets:
     * - Study progress (weight 25%)
     * - Workout completion (weight 20%)
     * - Work progress (weight 20%)
     * - Habits completion (weight 20%)
     * - Tasks completion & missed task penalty (weight 15%)
     *
     * Missing critical or high priority commitments directly reduces score significantly.
     */
    fun calculateScore(
        date: String,
        profile: UserProfileEntity,
        tasks: List<TaskEntity>,
        habits: List<HabitEntity>,
        habitLogs: List<HabitLogEntity>,
        studyMinutesTotal: Int,
        workoutMinutesTotal: Int,
        workMinutesTotal: Int
    ): DailyScoreEntity {
        val studyTarget = maxOf(1, profile.dailyStudyTargetMinutes)
        val workoutTarget = maxOf(1, profile.dailyWorkoutTargetMinutes)
        val workTarget = maxOf(1, profile.dailyWorkTargetMinutes)

        // Study component (0 to 25)
        val studyRatio = minOf(1.0f, studyMinutesTotal.toFloat() / studyTarget.toFloat())
        val studyScore = (studyRatio * 25f).toInt()

        // Workout component (0 to 20)
        val workoutRatio = minOf(1.0f, workoutMinutesTotal.toFloat() / workoutTarget.toFloat())
        val workoutScore = (workoutRatio * 20f).toInt()

        // Work component (0 to 20)
        val workRatio = minOf(1.0f, workMinutesTotal.toFloat() / workTarget.toFloat())
        val workScore = (workRatio * 20f).toInt()

        // Habits component (0 to 20)
        val totalHabits = habits.size
        val completedHabits = habitLogs.count { it.isCompleted }
        val habitScore = if (totalHabits > 0) {
            ((completedHabits.toFloat() / totalHabits.toFloat()) * 20f).toInt()
        } else {
            20 // No habits defined
        }

        // Tasks component (0 to 15) with Missed Penalty
        val totalTasks = tasks.size
        val completedTasks = tasks.count { it.status == TaskStatus.COMPLETED }
        val missedTasks = tasks.count { it.status == TaskStatus.MISSED }

        var taskScore = if (totalTasks > 0) {
            ((completedTasks.toFloat() / totalTasks.toFloat()) * 15f).toInt()
        } else {
            15
        }

        // Penalty for missed commitments (5 points per missed task)
        val missedPenalty = missedTasks * 5
        taskScore = maxOf(0, taskScore - missedPenalty)

        val totalScore = minOf(100, maxOf(0, studyScore + workoutScore + workScore + habitScore + taskScore))

        return DailyScoreEntity(
            date = date,
            totalScore = totalScore,
            studyMinutes = studyMinutesTotal,
            studyTargetMinutes = studyTarget,
            workoutMinutes = workoutMinutesTotal,
            workoutTargetMinutes = workoutTarget,
            workMinutes = workMinutesTotal,
            workTargetMinutes = workTarget,
            habitsCompleted = completedHabits,
            habitsTotal = totalHabits,
            tasksCompleted = completedTasks,
            tasksTotal = totalTasks,
            tasksMissed = missedTasks,
            sleepConsistencyScore = 95
        )
    }
}
