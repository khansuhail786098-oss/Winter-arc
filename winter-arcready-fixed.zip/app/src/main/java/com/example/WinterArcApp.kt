package com.example

import android.app.Application
import com.example.alarm.NotificationHelper
import com.example.data.local.WinterArcDatabase
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.UserProfileEntity
import com.example.data.local.entity.WinterArcEntity
import com.example.data.repository.WinterArcRepository
import com.example.domain.DateUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class WinterArcApp : Application() {

    lateinit var repository: WinterArcRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val database = WinterArcDatabase.getDatabase(this)
        repository = WinterArcRepository(this, database)

        // Setup notification channels
        NotificationHelper.createNotificationChannels(this)

        // Initialize default app entities if first launch
        CoroutineScope(Dispatchers.IO).launch {
            val today = DateUtils.todayString()

            val user = database.userDao().getUserProfileDirect()
            if (user == null) {
                database.userDao().insertOrUpdateUser(
                    UserProfileEntity(
                        name = "Arc Commander",
                        age = 22,
                        wakeUpTime = "05:30",
                        sleepTime = "22:30",
                        dailyStudyTargetMinutes = 360,
                        dailyWorkoutTargetMinutes = 60,
                        dailyWorkTargetMinutes = 180,
                        isOnboarded = true
                    )
                )
            }

            val arc = database.userDao().getWinterArcDirect()
            if (arc == null) {
                database.userDao().insertOrUpdateWinterArc(
                    WinterArcEntity(
                        arcName = "WINTER ARC",
                        mainObjective = "Relentless discipline, physical mastery, deep focus & high performance.",
                        startDate = today,
                        endDate = DateUtils.getDayOffset(today, 90),
                        totalDays = 90,
                        isActive = true
                    )
                )
            }

            // Ensure completely clean database state without any demo/test data
            repository.clearAllData()

            val settings = database.settingsDao().getSettingsDirect()
            if (settings == null) {
                database.settingsDao().insertOrUpdateSettings(AppSettingsEntity())
            }
        }
    }
}
