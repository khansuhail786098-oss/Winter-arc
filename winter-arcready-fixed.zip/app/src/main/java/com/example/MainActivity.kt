package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.MainViewModel
import com.example.ui.screens.AlarmScreen
import com.example.ui.screens.AnalyticsScreen
import com.example.ui.screens.FocusScreen
import com.example.ui.screens.GoalsAndProjectsScreen
import com.example.ui.screens.NightReviewScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.PlannerScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StudyScreen
import com.example.ui.screens.TodayScreen
import com.example.ui.screens.WorkoutScreen
import com.example.ui.theme.FrostWhite
import com.example.ui.theme.IcyBlueLight
import com.example.ui.theme.IcyBluePrimary
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.TextDim

object Routes {
    const val TODAY = "today"
    const val PLANNER = "planner"
    const val STUDY = "study"
    const val WORKOUT = "workout"
    const val FOCUS = "focus?taskId={taskId}"
    const val ALARM = "alarm"
    const val ANALYTICS = "analytics"
    const val NIGHT_REVIEW = "night_review"
    const val GOALS = "goals"
    const val SETTINGS = "settings"
    const val ONBOARDING = "onboarding"

    fun focusRoute(taskId: Long? = null): String {
        return if (taskId != null) "focus?taskId=$taskId" else "focus"
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val mainViewModel: MainViewModel = viewModel()

                // Request notification permission on Android 13+
                val context = LocalContext.current
                var hasNotificationPermission by remember {
                    mutableStateOf(
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.POST_NOTIFICATIONS
                            ) == PackageManager.PERMISSION_GRANTED
                        } else true
                    )
                }

                val permissionLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { isGranted ->
                    hasNotificationPermission = isGranted
                }

                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPermission) {
                        permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }

                WinterArcAppContent(viewModel = mainViewModel)
            }
        }
    }
}

@Composable
fun WinterArcAppContent(viewModel: MainViewModel) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val userProfile by viewModel.userProfile.collectAsState()
    val startDestination = Routes.TODAY

    val showBottomBar = currentRoute in listOf(
        Routes.TODAY,
        Routes.PLANNER,
        Routes.STUDY,
        Routes.WORKOUT,
        Routes.ANALYTICS,
        Routes.GOALS,
        Routes.SETTINGS
    )

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianBlack),
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = SurfaceDark,
                    contentColor = FrostWhite,
                    tonalElevation = 8.dp
                ) {
                    val items = listOf(
                        Triple(Routes.TODAY, "Today", Icons.Default.Dashboard),
                        Triple(Routes.PLANNER, "Planner", Icons.Default.CalendarMonth),
                        Triple(Routes.STUDY, "Study", Icons.Default.MenuBook),
                        Triple(Routes.WORKOUT, "Workout", Icons.Default.FitnessCenter),
                        Triple(Routes.ANALYTICS, "Analytics", Icons.Default.Insights),
                        Triple(Routes.GOALS, "Goals", Icons.Default.Flag),
                        Triple(Routes.SETTINGS, "Settings", Icons.Default.Settings)
                    )

                    items.forEach { (route, label, icon) ->
                        val selected = currentRoute == route
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                if (currentRoute != route) {
                                    navController.navigate(route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = label,
                                    modifier = Modifier.size(20.dp),
                                    tint = if (selected) IcyBluePrimary else TextDim
                                )
                            },
                            label = {
                                Text(
                                    text = label,
                                    fontSize = 9.sp,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selected) IcyBlueLight else TextDim
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = IcyBluePrimary.copy(alpha = 0.15f)
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = startDestination,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Routes.ONBOARDING) {
                OnboardingScreen(
                    viewModel = viewModel,
                    onFinishOnboarding = {
                        navController.navigate(Routes.TODAY) {
                            popUpTo(Routes.ONBOARDING) { inclusive = true }
                        }
                    }
                )
            }

            composable(Routes.TODAY) {
                TodayScreen(
                    viewModel = viewModel,
                    onNavigateToPlanner = { navController.navigate(Routes.PLANNER) },
                    onNavigateToStudy = { navController.navigate(Routes.STUDY) },
                    onNavigateToWorkout = { navController.navigate(Routes.WORKOUT) },
                    onNavigateToFocus = { taskId -> navController.navigate(Routes.focusRoute(taskId)) },
                    onNavigateToAlarms = { navController.navigate(Routes.ALARM) },
                    onNavigateToNightReview = { navController.navigate(Routes.NIGHT_REVIEW) },
                    onNavigateToGoals = { navController.navigate(Routes.GOALS) }
                )
            }

            composable(Routes.PLANNER) {
                PlannerScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onEnterFocus = { taskId -> navController.navigate(Routes.focusRoute(taskId)) }
                )
            }

            composable(Routes.STUDY) {
                StudyScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onEnterFocus = { taskId -> navController.navigate(Routes.focusRoute(taskId)) }
                )
            }

            composable(Routes.WORKOUT) {
                WorkoutScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(
                route = "focus?taskId={taskId}",
                arguments = listOf(navArgument("taskId") {
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null
                })
            ) { backStackEntry ->
                val taskIdString = backStackEntry.arguments?.getString("taskId")
                val taskId = taskIdString?.toLongOrNull()
                FocusScreen(
                    viewModel = viewModel,
                    taskId = taskId,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable("focus") {
                FocusScreen(
                    viewModel = viewModel,
                    taskId = null,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Routes.ALARM) {
                AlarmScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Routes.ANALYTICS) {
                AnalyticsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Routes.NIGHT_REVIEW) {
                NightReviewScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Routes.GOALS) {
                GoalsAndProjectsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Routes.SETTINGS) {
                SettingsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
    }
}
