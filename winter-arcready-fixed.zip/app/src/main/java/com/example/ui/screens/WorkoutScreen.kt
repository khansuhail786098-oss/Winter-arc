package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.WorkoutRoutineEntity
import com.example.domain.DateUtils
import com.example.ui.MainViewModel
import com.example.ui.components.EmptyState
import com.example.ui.components.PrimaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.FrostWhite
import com.example.ui.theme.IcyBlueLight
import com.example.ui.theme.IcyBluePrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceBorderSubtle
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WarningAmber
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorkoutScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTabIndex by remember { mutableIntStateOf(0) } // 0: Routines, 1: Rest Timer, 2: History
    val routines by viewModel.allWorkoutRoutines.collectAsState()
    val sessions by viewModel.allWorkoutSessions.collectAsState()

    var showLogWorkoutSheet by remember { mutableStateOf(false) }
    var showAddRoutineSheet by remember { mutableStateOf(false) }

    Box(modifier = modifier.fillMaxSize().background(ObsidianBlack)) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Surface(color = SurfaceDark, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onNavigateBack) {
                            Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = FrostWhite)
                        }
                        Text(
                            text = "WORKOUT & PHYSICAL PEAK",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.2.sp,
                                color = FrostWhite
                            )
                        )
                        IconButton(onClick = { selectedTabIndex = 1 }) {
                            Icon(imageVector = Icons.Default.Timer, contentDescription = "Timer", tint = SuccessGreen)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("TOTAL SESSIONS", style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 10.sp))
                            Text(
                                text = "${sessions.size} Completed",
                                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = FrostWhite)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("ACTIVE ROUTINES", style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 10.sp))
                            Text(
                                text = "${routines.size} Programs",
                                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = SuccessGreen)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    TabRow(
                        selectedTabIndex = selectedTabIndex,
                        containerColor = SurfaceDark,
                        contentColor = SuccessGreen,
                        indicator = { tabPositions ->
                            TabRowDefaults.SecondaryIndicator(
                                Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                                color = SuccessGreen
                            )
                        }
                    ) {
                        Tab(
                            selected = selectedTabIndex == 0,
                            onClick = { selectedTabIndex = 0 },
                            text = { Text("ROUTINES", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        Tab(
                            selected = selectedTabIndex == 1,
                            onClick = { selectedTabIndex = 1 },
                            text = { Text("REST STOPWATCH", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        Tab(
                            selected = selectedTabIndex == 2,
                            onClick = { selectedTabIndex = 2 },
                            text = { Text("LOGS", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            }

            when (selectedTabIndex) {
                0 -> {
                    // Routines list
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (routines.isEmpty()) {
                            item {
                                EmptyState(
                                    title = "No Workout Routines",
                                    message = "Define your training split (e.g. Push, Pull, Legs, Cardio) or log a workout session.",
                                    buttonText = "+ Create Workout Routine",
                                    onButtonClick = { showAddRoutineSheet = true }
                                )
                            }
                        } else {
                            items(routines, key = { it.id }) { routine ->
                                RoutineCard(
                                    routine = routine,
                                    onStartSession = { showLogWorkoutSheet = true }
                                )
                            }
                        }

                        item { Spacer(modifier = Modifier.height(80.dp)) }
                    }
                }
                1 -> {
                    // Rest Timer
                    RestTimerView()
                }
                2 -> {
                    // Logs
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            SectionHeader(
                                title = "Logged Workouts",
                                subtitle = "${sessions.size} Training Logs"
                            )
                        }

                        if (sessions.isEmpty()) {
                            item {
                                EmptyState(
                                    title = "No Workout Logs",
                                    message = "Completed workout sessions with sets, volume and notes will appear here.",
                                    buttonText = "+ Log Workout",
                                    onButtonClick = { showLogWorkoutSheet = true }
                                )
                            }
                        } else {
                            items(sessions, key = { it.id }) { s ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, SurfaceBorderSubtle),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = s.routineName,
                                                style = MaterialTheme.typography.labelMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = SuccessGreen
                                                )
                                            )
                                            Text(
                                                text = "${s.durationMinutes} min",
                                                style = MaterialTheme.typography.labelMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = FrostWhite
                                                )
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "${s.totalSets} Sets • ${s.totalReps} Reps • ${s.totalVolumeKg.toInt()} kg Volume",
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                fontWeight = FontWeight.SemiBold,
                                                color = FrostWhite
                                            )
                                        )
                                        if (s.notes.isNotBlank()) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = s.notes,
                                                style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        item { Spacer(modifier = Modifier.height(80.dp)) }
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { showLogWorkoutSheet = true },
            containerColor = SuccessGreen,
            contentColor = ObsidianBlack,
            shape = CircleShape,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "Log Workout")
        }
    }

    if (showLogWorkoutSheet) {
        LogWorkoutBottomSheet(
            onDismiss = { showLogWorkoutSheet = false },
            onSave = { name, dur, sets, reps, vol, notes ->
                viewModel.logWorkoutSession(name, dur, sets, reps, vol, notes)
            }
        )
    }

    if (showAddRoutineSheet) {
        AddWorkoutRoutineBottomSheet(
            onDismiss = { showAddRoutineSheet = false },
            onSave = { name, desc, mins, exercises ->
                viewModel.createWorkoutRoutine(name, desc, mins, exercises)
            }
        )
    }
}

@Composable
fun RoutineCard(
    routine: WorkoutRoutineEntity,
    onStartSession: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, SurfaceBorderSubtle),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(SuccessGreen.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.FitnessCenter,
                            contentDescription = null,
                            tint = SuccessGreen,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = routine.name,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = FrostWhite
                        )
                    )
                }

                Surface(
                    color = SuccessGreen.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "${routine.totalSessionsCompleted} LOGGED",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = SuccessGreen
                        ),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = routine.description,
                style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${routine.dayOfWeek} • ~${routine.estimatedMinutes}m",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = TextDim,
                        fontWeight = FontWeight.SemiBold
                    )
                )

                Surface(
                    color = SuccessGreen,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onStartSession() }
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = ObsidianBlack,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "EXECUTE ROUTINE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Black,
                                color = ObsidianBlack
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RestTimerView(modifier: Modifier = Modifier) {
    var totalSeconds by remember { mutableIntStateOf(90) }
    var secondsLeft by remember { mutableIntStateOf(90) }
    var isRunning by remember { mutableStateOf(false) }

    LaunchedEffect(isRunning, secondsLeft) {
        if (isRunning && secondsLeft > 0) {
            delay(1000L)
            secondsLeft -= 1
        } else if (secondsLeft == 0) {
            isRunning = false
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "BETWEEN-SET REST TIMER",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 1.5.sp,
                color = SuccessGreen
            )
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "Discipline in recovery ensures maximum progressive overload.",
            style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
        )

        Spacer(modifier = Modifier.height(28.dp))

        // Timer Display Box
        Box(
            modifier = Modifier
                .size(200.dp)
                .clip(CircleShape)
                .background(SurfaceDark),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                val mins = secondsLeft / 60
                val secs = secondsLeft % 60
                Text(
                    text = String.format("%02d:%02d", mins, secs),
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = if (secondsLeft <= 5) CriticalRed else FrostWhite
                    )
                )
                Text(
                    text = if (isRunning) "RESTING" else "READY",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isRunning) SuccessGreen else TextDim,
                        letterSpacing = 1.sp
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Quick Preset Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            listOf(45, 60, 90, 120, 180).forEach { preset ->
                Surface(
                    color = if (totalSeconds == preset) SuccessGreen else SurfaceElevated,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .padding(horizontal = 4.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            totalSeconds = preset
                            secondsLeft = preset
                            isRunning = false
                        }
                ) {
                    Text(
                        text = "${preset}s",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (totalSeconds == preset) ObsidianBlack else FrostWhite
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Control Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Surface(
                color = if (isRunning) WarningAmber else SuccessGreen,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .width(140.dp)
                    .height(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { isRunning = !isRunning }
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = ObsidianBlack
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isRunning) "PAUSE" else "START REST",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = ObsidianBlack
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Surface(
                color = SurfaceElevated,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .width(100.dp)
                    .height(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .clickable {
                        isRunning = false
                        secondsLeft = totalSeconds
                    }
            ) {
                Row(
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = "Reset", tint = FrostWhite)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "RESET",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = FrostWhite
                        )
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LogWorkoutBottomSheet(
    onDismiss: () -> Unit,
    onSave: (routineName: String, duration: Int, sets: Int, reps: Int, volume: Float, notes: String) -> Unit
) {
    val sheetState = androidx.compose.material3.rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var routineName by remember { mutableStateOf("") }
    var durationMinutes by remember { mutableStateOf("60") }
    var totalSets by remember { mutableStateOf("") }
    var totalReps by remember { mutableStateOf("") }
    var volumeKg by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceDark
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("LOG WORKOUT EXECUTION", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black, color = FrostWhite))
            Spacer(modifier = Modifier.height(14.dp))
            OutlinedTextField(
                value = routineName,
                onValueChange = { routineName = it },
                label = { Text("Routine / Focus (e.g. Push, Legs, Cardio)") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = durationMinutes,
                    onValueChange = { durationMinutes = it },
                    label = { Text("Minutes") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = totalSets,
                    onValueChange = { totalSets = it },
                    label = { Text("Sets") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = volumeKg,
                    onValueChange = { volumeKg = it },
                    label = { Text("Volume (kg)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Session PRs & Mobility Notes (Optional)") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )
            Spacer(modifier = Modifier.height(16.dp))
            PrimaryButton(
                text = "LOG PHYSICAL SESSION",
                onClick = {
                    if (routineName.isNotBlank()) {
                        val dur = durationMinutes.toIntOrNull() ?: 60
                        val sets = totalSets.toIntOrNull() ?: 0
                        val reps = totalReps.toIntOrNull() ?: 0
                        val vol = volumeKg.toFloatOrNull() ?: 0f
                        onSave(routineName.trim(), dur, sets, reps, vol, notes.trim())
                        onDismiss()
                    }
                }
            )
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddWorkoutRoutineBottomSheet(
    onDismiss: () -> Unit,
    onSave: (name: String, description: String, estimatedMinutes: Int, exercises: List<String>) -> Unit
) {
    val sheetState = androidx.compose.material3.rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var estimatedMinutesStr by remember { mutableStateOf("60") }
    var exercisesRaw by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceDark
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("CREATE WORKOUT ROUTINE", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black, color = FrostWhite))
            Spacer(modifier = Modifier.height(14.dp))
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Routine Name (e.g. Upper Body Hypertrophy)") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Target Split (e.g. Chest, Shoulders, Triceps)") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = estimatedMinutesStr,
                onValueChange = { estimatedMinutesStr = it },
                label = { Text("Estimated Duration (Minutes)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = exercisesRaw,
                onValueChange = { exercisesRaw = it },
                label = { Text("Exercises List (comma separated)") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )
            Spacer(modifier = Modifier.height(16.dp))
            PrimaryButton(
                text = "SAVE ROUTINE",
                onClick = {
                    if (name.isNotBlank()) {
                        val mins = estimatedMinutesStr.toIntOrNull() ?: 60
                        val exList = exercisesRaw.split(",")
                            .map { it.trim() }
                            .filter { it.isNotBlank() }
                        onSave(name.trim(), description.trim(), mins, exList)
                        onDismiss()
                    }
                }
            )
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
