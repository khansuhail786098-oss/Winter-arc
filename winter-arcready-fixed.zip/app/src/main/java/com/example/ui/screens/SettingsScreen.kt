package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.components.ConfirmDialog
import com.example.ui.components.PrimaryButton
import com.example.ui.components.SecondaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.CriticalRedBg
import com.example.ui.theme.FrostWhite
import com.example.ui.theme.IcyBlueLight
import com.example.ui.theme.IcyBluePrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceBorderSubtle
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WarningAmber
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val userProfile by viewModel.userProfile.collectAsState()
    val winterArc by viewModel.winterArc.collectAsState()

    var name by remember(userProfile) { mutableStateOf(userProfile?.name ?: "Arc Commander") }
    var wakeUpTime by remember(userProfile) { mutableStateOf(userProfile?.wakeUpTime ?: "05:30") }
    var sleepTime by remember(userProfile) { mutableStateOf(userProfile?.sleepTime ?: "22:30") }
    var studyHours by remember(userProfile) { mutableStateOf(((userProfile?.dailyStudyTargetMinutes ?: 360) / 60).toString()) }
    var workoutMinutes by remember(userProfile) { mutableStateOf((userProfile?.dailyWorkoutTargetMinutes ?: 60).toString()) }
    var workHours by remember(userProfile) { mutableStateOf(((userProfile?.dailyWorkTargetMinutes ?: 180) / 60).toString()) }

    var arcName by remember(winterArc) { mutableStateOf(winterArc?.arcName ?: "WINTER ARC") }
    var mainObjective by remember(winterArc) { mutableStateOf(winterArc?.mainObjective ?: "Relentless discipline and physical mastery.") }

    var showConfirmWipeDialog by remember { mutableStateOf(false) }

    Box(modifier = modifier.fillMaxSize().background(ObsidianBlack)) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = FrostWhite)
                    }
                    Text(
                        text = "SETTINGS & ARC CONTROLS",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.2.sp,
                            color = FrostWhite
                        )
                    )
                    Spacer(modifier = Modifier.width(48.dp))
                }
            }

            // Commander Profile Section
            item {
                SectionHeader(title = "Discipline Cadence & Targets")
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, SurfaceBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("Commander Call-Sign / Name") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = IcyBluePrimary,
                                unfocusedBorderColor = SurfaceBorder,
                                focusedTextColor = FrostWhite,
                                unfocusedTextColor = FrostWhite
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = wakeUpTime,
                                onValueChange = { wakeUpTime = it },
                                label = { Text("Wake Time") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = IcyBluePrimary,
                                    unfocusedBorderColor = SurfaceBorder,
                                    focusedTextColor = FrostWhite,
                                    unfocusedTextColor = FrostWhite
                                ),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = sleepTime,
                                onValueChange = { sleepTime = it },
                                label = { Text("Sleep Time") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = IcyBluePrimary,
                                    unfocusedBorderColor = SurfaceBorder,
                                    focusedTextColor = FrostWhite,
                                    unfocusedTextColor = FrostWhite
                                ),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = studyHours,
                                onValueChange = { studyHours = it },
                                label = { Text("Study Target (h)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = workoutMinutes,
                                onValueChange = { workoutMinutes = it },
                                label = { Text("Workout (m)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = workHours,
                                onValueChange = { workHours = it },
                                label = { Text("Work (h)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        PrimaryButton(
                            text = "SAVE TARGETS",
                            icon = Icons.Default.Save,
                            onClick = {
                                val sH = studyHours.toIntOrNull() ?: 6
                                val wM = workoutMinutes.toIntOrNull() ?: 60
                                val wkH = workHours.toIntOrNull() ?: 3
                                viewModel.saveOnboardingProfile(
                                    name = name,
                                    age = userProfile?.age ?: 22,
                                    wakeUpTime = wakeUpTime,
                                    sleepTime = sleepTime,
                                    studyHours = sH,
                                    workoutMinutes = wM,
                                    workHours = wkH,
                                    arcName = arcName,
                                    mainObjective = mainObjective,
                                    startDate = winterArc?.startDate ?: "",
                                    endDate = winterArc?.endDate ?: "",
                                    primaryGoalTitle = "",
                                    primaryGoalCategory = ""
                                )
                                Toast.makeText(context, "Targets updated successfully", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }

            // Winter Arc Directive Section
            item {
                SectionHeader(title = "Winter Arc Mission Objective")
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, SurfaceBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        OutlinedTextField(
                            value = arcName,
                            onValueChange = { arcName = it },
                            label = { Text("Arc Protocol Name") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = mainObjective,
                            onValueChange = { mainObjective = it },
                            label = { Text("Master 90-Day Directive") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }
                }
            }

            // Data & System Controls
            item {
                SectionHeader(title = "Data Engine & Diagnostics")
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, SurfaceBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        SecondaryButton(
                            text = "EXPORT DATA BACKUP (JSON TO CLIPBOARD)",
                            icon = Icons.Default.Download,
                            onClick = {
                                coroutineScope.launch {
                                    val repo = (context.applicationContext as com.example.WinterArcApp).repository
                                    val json = repo.exportDataAsJson()
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("WinterArcBackup", json))
                                    Toast.makeText(context, "Exported JSON copied to clipboard!", Toast.LENGTH_LONG).show()
                                }
                            }
                        )

                        SecondaryButton(
                            text = "WIPE ALL APP DATA",
                            icon = Icons.Default.DeleteForever,
                            onClick = { showConfirmWipeDialog = true }
                        )
                    }
                }
            }

            // About OS card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, SurfaceBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = IcyBluePrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("WINTER ARC PERSONAL OPERATING SYSTEM", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = FrostWhite))
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Version 1.0.0 • Local-First Architecture • Zero Cloud Dependencies • Engineered for Relentless Focus & Self-Mastery.",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextDim, fontSize = 11.sp)
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }

    if (showConfirmWipeDialog) {
        ConfirmDialog(
            title = "Wipe All Data?",
            message = "This will permanently clear all tasks, study logs, workouts, habits and scores.",
            confirmText = "Wipe Everything",
            onConfirm = {
                showConfirmWipeDialog = false
                viewModel.clearAllData()
                Toast.makeText(context, "Database cleared.", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { showConfirmWipeDialog = false }
        )
    }
}
