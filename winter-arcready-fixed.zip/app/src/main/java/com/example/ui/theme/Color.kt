package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Winter Arc Aesthetic Palette
// Cold, minimal, high-contrast, obsidian dark canvas with icy blue accents

val ObsidianBlack = Color(0xFF06090E)
val CharcoalDark = Color(0xFF0D121D)
val SurfaceDark = Color(0xFF131B2A)
val SurfaceElevated = Color(0xFF1A2438)
val SurfaceBorder = Color(0xFF24324D)
val SurfaceBorderSubtle = Color(0xFF1E293B)

val IcyBluePrimary = Color(0xFF38BDF8)
val IcyBlueLight = Color(0xFF7DD3FC)
val IcyBlueDark = Color(0xFF0284C7)
val FrostWhite = Color(0xFFF8FAFC)
val FrostMuted = Color(0xFFCBD5E1)
val TextMuted = Color(0xFF94A3B8)
val TextDim = Color(0xFF64748B)

// Semantic Indicator Colors
val SuccessGreen = Color(0xFF10B981)
val SuccessGreenDark = Color(0xFF047857)
val SuccessGreenBg = Color(0xFF064E3B)

val WarningAmber = Color(0xFFF59E0B)
val WarningAmberDark = Color(0xFFB45309)
val WarningAmberBg = Color(0xFF78350F)

val CriticalRed = Color(0xFFEF4444)
val CriticalRedDark = Color(0xFFB91C1C)
val CriticalRedBg = Color(0xFF7F1D1D)

val PurpleAccent = Color(0xFFA855F7)
val CyanAccent = Color(0xFF06B6D4)
val BlueAccent = Color(0xFF3B82F6)

// Glassmorphism overlays
val GlassOverlay = Color(0x1A38BDF8)
val GlassCard = Color(0x99131B2A)
val GlassCardBorder = Color(0x4D38BDF8)
