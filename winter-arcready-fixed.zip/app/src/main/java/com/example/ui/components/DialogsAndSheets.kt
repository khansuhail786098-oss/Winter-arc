package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.TaskCategory
import com.example.data.local.entity.TaskEntity
import com.example.data.local.entity.TaskPriority
import com.example.domain.DateUtils
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.FrostWhite
import com.example.ui.theme.IcyBluePrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceBorderSubtle
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WarningAmber

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditTaskBottomSheet(
    initialTask: TaskEntity? = null,
    defaultDate: String = DateUtils.todayString(),
    onDismiss: () -> Unit,
    onSave: (
        id: Long,
        title: String,
        description: String,
        category: TaskCategory,
        priority: TaskPriority,
        plannedDate: String,
        startTime: String,
        endTime: String,
        durationMinutes: Int,
        isAlarmEnabled: Boolean,
        isHighAlertEnabled: Boolean
    ) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var title by remember { mutableStateOf(initialTask?.title ?: "") }
    var description by remember { mutableStateOf(initialTask?.description ?: "") }
    var category by remember { mutableStateOf(initialTask?.category ?: TaskCategory.STUDY) }
    var priority by remember { mutableStateOf(initialTask?.priority ?: TaskPriority.NORMAL) }
    var plannedDate by remember { mutableStateOf(initialTask?.plannedDate ?: defaultDate) }
    var startTime by remember { mutableStateOf(initialTask?.startTime ?: "08:00") }
    var endTime by remember { mutableStateOf(initialTask?.endTime ?: "09:30") }
    var durationMinutes by remember { mutableStateOf(initialTask?.durationMinutes?.toString() ?: "90") }
    var isAlarmEnabled by remember { mutableStateOf(initialTask?.isAlarmEnabled ?: true) }
    var isHighAlertEnabled by remember { mutableStateOf(initialTask?.isHighAlertEnabled ?: false) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceDark,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (initialTask == null) "NEW COMMITMENT" else "EDIT COMMITMENT",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.2.sp,
                        color = FrostWhite
                    )
                )
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Title
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Task Title *") },
                placeholder = { Text("e.g. Physics — Gauss Law Derivations") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = IcyBluePrimary,
                    unfocusedBorderColor = SurfaceBorder,
                    focusedTextColor = FrostWhite,
                    unfocusedTextColor = FrostWhite
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Description
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Directive / Notes (Optional)") },
                placeholder = { Text("Specify deliverables, problem numbers, or focus rules...") },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = IcyBluePrimary,
                    unfocusedBorderColor = SurfaceBorder,
                    focusedTextColor = FrostWhite,
                    unfocusedTextColor = FrostWhite
                ),
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Category Chips
            Text(
                text = "CATEGORY",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextMuted
                )
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                TaskCategory.values().take(4).forEach { cat ->
                    FilterChip(
                        selected = category == cat,
                        onClick = { category = cat },
                        label = { Text(cat.name, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = IcyBluePrimary,
                            selectedLabelColor = ObsidianBlack,
                            containerColor = SurfaceElevated,
                            labelColor = TextMuted
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Priority Selection
            Text(
                text = "PRIORITY LEVEL",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextMuted
                )
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TaskPriority.values().forEach { prio ->
                    val isSel = priority == prio
                    Surface(
                        color = if (isSel) {
                            when (prio) {
                                TaskPriority.CRITICAL -> CriticalRed
                                TaskPriority.HIGH -> WarningAmber
                                TaskPriority.NORMAL -> IcyBluePrimary
                            }
                        } else SurfaceElevated,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { priority = prio }
                    ) {
                        Text(
                            text = prio.name,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isSel) ObsidianBlack else TextMuted
                            ),
                            modifier = Modifier.padding(vertical = 8.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Time & Duration
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = startTime,
                    onValueChange = { startTime = it },
                    label = { Text("Start (HH:mm)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = IcyBluePrimary,
                        unfocusedBorderColor = SurfaceBorder,
                        focusedTextColor = FrostWhite,
                        unfocusedTextColor = FrostWhite
                    ),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = endTime,
                    onValueChange = { endTime = it },
                    label = { Text("End (HH:mm)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = IcyBluePrimary,
                        unfocusedBorderColor = SurfaceBorder,
                        focusedTextColor = FrostWhite,
                        unfocusedTextColor = FrostWhite
                    ),
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = durationMinutes,
                    onValueChange = { durationMinutes = it },
                    label = { Text("Minutes") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = IcyBluePrimary,
                        unfocusedBorderColor = SurfaceBorder,
                        focusedTextColor = FrostWhite,
                        unfocusedTextColor = FrostWhite
                    ),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Alarm & High Alert Toggles
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Exact Task Alarm", style = MaterialTheme.typography.titleSmall.copy(color = FrostWhite))
                    Text("Trigger audible alarm at start time", style = MaterialTheme.typography.bodySmall.copy(color = TextDim))
                }
                Switch(
                    checked = isAlarmEnabled,
                    onCheckedChange = { isAlarmEnabled = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = IcyBluePrimary)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("High Alert Mode (5 Stages)", style = MaterialTheme.typography.titleSmall.copy(color = CriticalRed))
                    Text("Escalates alert if unacknowledged", style = MaterialTheme.typography.bodySmall.copy(color = TextDim))
                }
                Switch(
                    checked = isHighAlertEnabled,
                    onCheckedChange = { isHighAlertEnabled = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = CriticalRed)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            PrimaryButton(
                text = if (initialTask == null) "CREATE COMMITMENT" else "UPDATE COMMITMENT",
                onClick = {
                    if (title.isNotBlank()) {
                        val dur = durationMinutes.toIntOrNull() ?: 60
                        onSave(
                            initialTask?.id ?: 0L,
                            title,
                            description,
                            category,
                            priority,
                            plannedDate,
                            startTime,
                            endTime,
                            dur,
                            isAlarmEnabled,
                            isHighAlertEnabled
                        )
                        onDismiss()
                    }
                },
                enabled = title.isNotBlank()
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditGoalBottomSheet(
    onDismiss: () -> Unit,
    onSave: (title: String, description: String, category: String, priority: TaskPriority, deadline: String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Academics") }
    var deadline by remember { mutableStateOf(DateUtils.getDayOffset(DateUtils.todayString(), 60)) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceDark
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("SET PRIMARY GOAL", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = FrostWhite))
            Spacer(modifier = Modifier.height(14.dp))
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Goal Title *") },
                placeholder = { Text("e.g. Crack National Competitive Exam") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Description & Milestone Outline") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = deadline,
                onValueChange = { deadline = it },
                label = { Text("Target Deadline (YYYY-MM-DD)") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(18.dp))
            PrimaryButton(
                text = "COMMIT TO GOAL",
                onClick = {
                    if (title.isNotBlank()) {
                        onSave(title, description, category, TaskPriority.CRITICAL, deadline)
                        onDismiss()
                    }
                },
                enabled = title.isNotBlank()
            )
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditHabitBottomSheet(
    onDismiss: () -> Unit,
    onSave: (name: String, iconName: String, targetDaysPerWeek: Int, reminderTime: String) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var name by remember { mutableStateOf("") }
    var reminderTime by remember { mutableStateOf("07:00") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceDark
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("NEW DAILY HABIT", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = FrostWhite))
            Spacer(modifier = Modifier.height(14.dp))
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Habit Name *") },
                placeholder = { Text("e.g. Cold Shower & Breathing Protocol") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = reminderTime,
                onValueChange = { reminderTime = it },
                label = { Text("Reminder Time (HH:mm)") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(18.dp))
            PrimaryButton(
                text = "ESTABLISH HABIT",
                onClick = {
                    if (name.isNotBlank()) {
                        onSave(name, "bolt", 7, reminderTime)
                        onDismiss()
                    }
                },
                enabled = name.isNotBlank()
            )
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun ConfirmDialog(
    title: String,
    message: String,
    confirmText: String = "Confirm",
    dismissText: String = "Cancel",
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, color = FrostWhite, fontWeight = FontWeight.Bold) },
        text = { Text(message, color = TextMuted) },
        containerColor = SurfaceDark,
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(confirmText, color = CriticalRed, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(dismissText, color = FrostWhite)
            }
        }
    )
}
