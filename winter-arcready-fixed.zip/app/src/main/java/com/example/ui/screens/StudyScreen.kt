package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.StudyRevisionEntity
import com.example.data.local.entity.StudySubjectEntity
import com.example.domain.DateUtils
import com.example.ui.MainViewModel
import com.example.ui.components.EmptyState
import com.example.ui.components.PrimaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.FrostWhite
import com.example.ui.theme.IcyBlueDark
import com.example.ui.theme.IcyBlueLight
import com.example.ui.theme.IcyBluePrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceBorderSubtle
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WarningAmber

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onEnterFocus: (taskId: Long?) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTabIndex by remember { mutableStateOf(0) } // 0: Subjects & Syllabus, 1: Spaced Repetition, 2: History
    var showLogSessionSheet by remember { mutableStateOf(false) }
    var showAddSubjectSheet by remember { mutableStateOf(false) }

    val subjects by viewModel.allSubjects.collectAsState()
    val revisions by viewModel.pendingRevisions.collectAsState()
    val sessions by viewModel.allStudySessions.collectAsState()

    val totalStudyHours = sessions.sumOf { it.durationMinutes } / 60f

    Box(modifier = modifier.fillMaxSize().background(ObsidianBlack)) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Surface(color = SurfaceDark, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onNavigateBack) {
                            Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = FrostWhite)
                        }
                        Text(
                            text = "ACADEMIC STUDY ENGINE",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.2.sp,
                                color = FrostWhite
                            )
                        )
                        IconButton(onClick = { onEnterFocus(null) }) {
                            Icon(imageVector = Icons.Default.Timer, contentDescription = "Focus", tint = IcyBluePrimary)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("ACCUMULATED STUDY", style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 10.sp))
                            Text(
                                text = String.format("%.1f Hours", totalStudyHours),
                                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = FrostWhite)
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("PENDING REVISIONS", style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 10.sp))
                            Text(
                                text = "${revisions.size} Topics",
                                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = IcyBlueLight)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    TabRow(
                        selectedTabIndex = selectedTabIndex,
                        containerColor = SurfaceDark,
                        contentColor = IcyBluePrimary,
                        indicator = { tabPositions ->
                            TabRowDefaults.SecondaryIndicator(
                                Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                                color = IcyBluePrimary
                            )
                        }
                    ) {
                        Tab(
                            selected = selectedTabIndex == 0,
                            onClick = { selectedTabIndex = 0 },
                            text = { Text("SYLLABUS", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        Tab(
                            selected = selectedTabIndex == 1,
                            onClick = { selectedTabIndex = 1 },
                            text = { Text("SPACED REPETITION (${revisions.size})", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        Tab(
                            selected = selectedTabIndex == 2,
                            onClick = { selectedTabIndex = 2 },
                            text = { Text("LOGS", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            }

            // Tab Contents
            when (selectedTabIndex) {
                0 -> {
                    // Syllabus Subjects
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (subjects.isEmpty()) {
                            item {
                                EmptyState(
                                    title = "No Subjects Configured",
                                    message = "Define subjects, syllabus chapters and hour targets.",
                                    buttonText = "+ Create Subject",
                                    onButtonClick = { showAddSubjectSheet = true }
                                )
                            }
                        } else {
                            items(subjects, key = { it.id }) { subject ->
                                SubjectCard(
                                    subject = subject,
                                    onLogSession = { showLogSessionSheet = true },
                                    onScheduleRevision = {
                                        viewModel.scheduleSpacedRevisions(subject.name, "Core Derivations Mastery")
                                    }
                                )
                            }
                        }

                        item { Spacer(modifier = Modifier.height(80.dp)) }
                    }
                }
                1 -> {
                    // Spaced Repetition Queue (1, 3, 7, 14, 30 days)
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            SectionHeader(
                                title = "Active Revision Queue",
                                subtitle = "Spaced repetition based on the Ebbinghaus forgetting curve"
                            )
                        }

                        if (revisions.isEmpty()) {
                            item {
                                EmptyState(
                                    title = "All Revisions Completed",
                                    message = "No pending spaced revisions scheduled for today. Keep logging study sessions."
                                )
                            }
                        } else {
                            items(revisions, key = { it.id }) { rev ->
                                RevisionItemCard(
                                    revision = rev,
                                    onComplete = { viewModel.completeRevision(rev) }
                                )
                            }
                        }

                        item { Spacer(modifier = Modifier.height(80.dp)) }
                    }
                }
                2 -> {
                    // Study History
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        item {
                            SectionHeader(
                                title = "Logged Study Blocks",
                                subtitle = "${sessions.size} Deep Focus Sessions"
                            )
                        }

                        if (sessions.isEmpty()) {
                            item {
                                EmptyState(
                                    title = "No Sessions Logged",
                                    message = "Completed study sessions will appear here with notes and time logs.",
                                    buttonText = "+ Log Study Session",
                                    onButtonClick = { showLogSessionSheet = true }
                                )
                            }
                        } else {
                            items(sessions, key = { it.id }) { session ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, SurfaceBorderSubtle),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = session.subjectName,
                                                style = MaterialTheme.typography.labelMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = IcyBlueLight
                                                )
                                            )
                                            Text(
                                                text = "${session.durationMinutes} min",
                                                style = MaterialTheme.typography.labelMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = SuccessGreen
                                                )
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "${session.chapterTitle} • ${session.topicTitle}",
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                fontWeight = FontWeight.SemiBold,
                                                color = FrostWhite
                                            )
                                        )
                                        if (session.notes.isNotBlank()) {
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = session.notes,
                                                style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        item { Spacer(modifier = Modifier.height(80.dp)) }
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { showLogSessionSheet = true },
            containerColor = IcyBluePrimary,
            contentColor = ObsidianBlack,
            shape = CircleShape,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "Log Session")
        }
    }

    if (showLogSessionSheet) {
        LogStudySessionBottomSheet(
            onDismiss = { showLogSessionSheet = false },
            onSave = { subject, ch, top, dur, notes ->
                viewModel.logStudySession(subject, ch, top, dur, notes)
                if (top.isNotBlank()) {
                    viewModel.scheduleSpacedRevisions(subject, top)
                }
            }
        )
    }

    if (showAddSubjectSheet) {
        AddSubjectBottomSheet(
            onDismiss = { showAddSubjectSheet = false },
            onSave = { name, totalHours, chapters ->
                viewModel.createStudySubject(name, totalHours, chapters)
            }
        )
    }
}

@Composable
fun SubjectCard(
    subject: StudySubjectEntity,
    onLogSession: () -> Unit,
    onScheduleRevision: () -> Unit,
    modifier: Modifier = Modifier
) {
    val progress = minOf(1f, subject.completedHours / maxOf(1, subject.targetHoursTotal).toFloat())

    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, SurfaceBorderSubtle),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(IcyBluePrimary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = null,
                            tint = IcyBluePrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = subject.name,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = FrostWhite
                        )
                    )
                }

                Text(
                    text = "${subject.completedHours.toInt()} / ${subject.targetHoursTotal}h",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = IcyBlueLight
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Progress bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(SurfaceElevated)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progress)
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(IcyBluePrimary)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Surface(
                    color = SurfaceElevated,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onScheduleRevision() }
                ) {
                    Text(
                        text = "Schedule Spaced Revisions",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = FrostWhite
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Surface(
                    color = IcyBluePrimary,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onLogSession() }
                ) {
                    Text(
                        text = "+ Log Session",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = ObsidianBlack
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun RevisionItemCard(
    revision: StudyRevisionEntity,
    onComplete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, IcyBluePrimary.copy(alpha = 0.3f)),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = IcyBluePrimary.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "INTERVAL: ${revision.intervalDay}D",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = IcyBlueLight
                            ),
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = revision.subjectName,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextMuted
                        )
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = revision.topicTitle,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = FrostWhite
                    )
                )
                Text(
                    text = "Scheduled: ${DateUtils.formatShortDisplayDate(revision.scheduledDate)}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextDim,
                        fontSize = 11.sp
                    )
                )
            }

            Surface(
                color = SuccessGreen,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onComplete() }
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Done",
                        tint = ObsidianBlack,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "DONE",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Black,
                            color = ObsidianBlack
                        )
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LogStudySessionBottomSheet(
    onDismiss: () -> Unit,
    onSave: (subject: String, chapter: String, topic: String, duration: Int, notes: String) -> Unit
) {
    val sheetState = androidx.compose.material3.rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var subject by remember { mutableStateOf("") }
    var chapter by remember { mutableStateOf("") }
    var topic by remember { mutableStateOf("") }
    var durationMinutes by remember { mutableStateOf("60") }
    var notes by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceDark
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("LOG STUDY SESSION", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black, color = FrostWhite))
            Spacer(modifier = Modifier.height(14.dp))
            OutlinedTextField(
                value = subject,
                onValueChange = { subject = it },
                label = { Text("Subject (e.g. Physics, Math, Code)") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = chapter,
                onValueChange = { chapter = it },
                label = { Text("Chapter / Module") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = topic,
                onValueChange = { topic = it },
                label = { Text("Topic / Problem Set") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = durationMinutes,
                onValueChange = { durationMinutes = it },
                label = { Text("Duration (Minutes)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Session Notes & Key Insights (Optional)") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )
            Spacer(modifier = Modifier.height(16.dp))
            PrimaryButton(
                text = "LOG SESSION & QUEUE REVISION",
                onClick = {
                    if (subject.isNotBlank()) {
                        val dur = durationMinutes.toIntOrNull() ?: 60
                        onSave(subject.trim(), chapter.trim(), topic.trim(), dur, notes.trim())
                        onDismiss()
                    }
                }
            )
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddSubjectBottomSheet(
    onDismiss: () -> Unit,
    onSave: (name: String, totalHours: Int, chapters: List<String>) -> Unit
) {
    val sheetState = androidx.compose.material3.rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var name by remember { mutableStateOf("") }
    var totalHoursStr by remember { mutableStateOf("100") }
    var chaptersRaw by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = SurfaceDark
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("CREATE STUDY SUBJECT", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black, color = FrostWhite))
            Spacer(modifier = Modifier.height(14.dp))
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Subject Name (e.g. Organic Chemistry)") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = totalHoursStr,
                onValueChange = { totalHoursStr = it },
                label = { Text("Target Study Hours (e.g. 100)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = chaptersRaw,
                onValueChange = { chaptersRaw = it },
                label = { Text("Chapters / Syllabus Topics (comma separated)") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2
            )
            Spacer(modifier = Modifier.height(16.dp))
            PrimaryButton(
                text = "CREATE SUBJECT & SYLLABUS",
                onClick = {
                    if (name.isNotBlank()) {
                        val hours = totalHoursStr.toIntOrNull() ?: 100
                        val chaptersList = chaptersRaw.split(",")
                            .map { it.trim() }
                            .filter { it.isNotBlank() }
                        onSave(name.trim(), hours, chaptersList)
                        onDismiss()
                    }
                }
            )
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
