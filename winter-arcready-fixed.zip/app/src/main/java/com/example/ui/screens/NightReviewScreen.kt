package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.History
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.DateUtils
import com.example.ui.MainViewModel
import com.example.ui.components.EmptyState
import com.example.ui.components.PrimaryButton
import com.example.ui.components.SectionHeader
import com.example.ui.theme.FrostWhite
import com.example.ui.theme.IcyBlueDark
import com.example.ui.theme.IcyBlueLight
import com.example.ui.theme.IcyBluePrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceBorderSubtle
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted

@Composable
fun NightReviewScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Tonight's Review, 1: Past Reviews
    val uiState by viewModel.todayUiState.collectAsState()
    val allReviews by viewModel.allDailyScores.collectAsState() // or review list

    var whatWentWell by remember { mutableStateOf("") }
    var whatMissed by remember { mutableStateOf("") }
    var whyMissed by remember { mutableStateOf("") }
    var whatToChangeTomorrow by remember { mutableStateOf("") }
    var tomorrowPriority by remember { mutableStateOf("") }
    var savedConfirmation by remember { mutableStateOf(false) }

    Box(modifier = modifier.fillMaxSize().background(ObsidianBlack)) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Surface(color = SurfaceDark, modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onNavigateBack) {
                            Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = FrostWhite)
                        }
                        Text(
                            text = "NIGHTLY PROTOCOL DEBRIEF",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.2.sp,
                                color = FrostWhite
                            )
                        )
                        Spacer(modifier = Modifier.width(48.dp))
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "DAY ${uiState.arcDayNumber} • TODAY'S SCORE: ${uiState.todayScore.totalScore}%",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = IcyBlueLight,
                            letterSpacing = 1.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    TabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = SurfaceDark,
                        contentColor = IcyBluePrimary,
                        indicator = { tabPositions ->
                            TabRowDefaults.SecondaryIndicator(
                                Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                                color = IcyBluePrimary
                            )
                        }
                    ) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            text = { Text("TONIGHT'S REVIEW", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        Tab(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            text = { Text("REVIEW ARCHIVE", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            }

            if (selectedTab == 0) {
                // Tonight's form
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, SurfaceBorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "1. What went well today? (Wins & Milestones)",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = FrostWhite)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = whatWentWell,
                                onValueChange = { whatWentWell = it },
                                placeholder = { Text("e.g. Cleared 25 Physics numericals, woke at 05:30 without hesitation.") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = IcyBluePrimary,
                                    unfocusedBorderColor = SurfaceBorder,
                                    focusedTextColor = FrostWhite,
                                    unfocusedTextColor = FrostWhite
                                ),
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, SurfaceBorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "2. What commitments were missed or slipped?",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = FrostWhite)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = whatMissed,
                                onValueChange = { whatMissed = it },
                                placeholder = { Text("e.g. Afternoon coding block pushed back 45 minutes.") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = IcyBluePrimary,
                                    unfocusedBorderColor = SurfaceBorder,
                                    focusedTextColor = FrostWhite,
                                    unfocusedTextColor = FrostWhite
                                ),
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, SurfaceBorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "3. Honest Root Cause & Corrective Strategy",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = FrostWhite)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = whyMissed,
                                onValueChange = { whyMissed = it },
                                placeholder = { Text("e.g. Checked messages right after lunch. Fix: Phone in locker during lunch.") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = IcyBluePrimary,
                                    unfocusedBorderColor = SurfaceBorder,
                                    focusedTextColor = FrostWhite,
                                    unfocusedTextColor = FrostWhite
                                ),
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceElevated),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, IcyBluePrimary.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "4. Tomorrow's Non-Negotiable #1 Priority Task",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Black, color = IcyBlueLight)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = tomorrowPriority,
                                onValueChange = { tomorrowPriority = it },
                                placeholder = { Text("e.g. Master Gauss Law derivation proofs in 08:00 morning block.") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = IcyBluePrimary,
                                    unfocusedBorderColor = SurfaceBorder,
                                    focusedTextColor = FrostWhite,
                                    unfocusedTextColor = FrostWhite
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    PrimaryButton(
                        text = "LOCK IN NIGHTLY REVIEW",
                        icon = Icons.Default.CheckCircle,
                        onClick = {
                            viewModel.saveDailyReview(
                                whatWentWell = whatWentWell,
                                whatMissed = whatMissed,
                                whyMissed = whyMissed,
                                whatToChangeTomorrow = whatToChangeTomorrow,
                                tomorrowPriority = tomorrowPriority,
                                notes = "Day ${uiState.arcDayNumber} complete."
                            )
                            savedConfirmation = true
                        }
                    )

                    if (savedConfirmation) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "✓ Day ${uiState.arcDayNumber} review locked in. Rest well for tomorrow's execution.",
                            style = MaterialTheme.typography.bodySmall.copy(color = SuccessGreen),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Spacer(modifier = Modifier.height(80.dp))
                }
            } else {
                // Archive tab
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        SectionHeader(
                            title = "Historical Reviews",
                            subtitle = "Past reflections and discipline adjustments"
                        )
                    }

                    items(DateUtils.getPastWeekDates()) { dateStr ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, SurfaceBorderSubtle),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = DateUtils.formatDisplayDate(dateStr),
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = FrostWhite
                                        )
                                    )
                                    Surface(
                                        color = IcyBluePrimary.copy(alpha = 0.15f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = "REVIEWED",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = IcyBlueLight,
                                                fontWeight = FontWeight.Bold
                                            ),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "All primary study & workout commitments met without friction.",
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                                )
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(80.dp)) }
                }
            }
        }
    }
}
