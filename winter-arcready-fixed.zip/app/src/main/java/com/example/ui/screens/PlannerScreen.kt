package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.TaskEntity
import com.example.data.local.entity.TaskPriority
import com.example.data.local.entity.TaskStatus
import com.example.domain.DateUtils
import com.example.ui.MainViewModel
import com.example.ui.components.AddEditTaskBottomSheet
import com.example.ui.components.CategoryBadge
import com.example.ui.components.EmptyState
import com.example.ui.components.PriorityBadge
import com.example.ui.components.TaskCard
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.FrostWhite
import com.example.ui.theme.IcyBlueDark
import com.example.ui.theme.IcyBlueLight
import com.example.ui.theme.IcyBluePrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceBorderSubtle
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WarningAmber

@Composable
fun PlannerScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    onEnterFocus: (taskId: Long?) -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedDate by viewModel.selectedDate.collectAsState()
    val allTasks by viewModel.allTasks.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()

    var showAddTaskSheet by remember { mutableStateOf(false) }
    var selectedTaskForEdit by remember { mutableStateOf<TaskEntity?>(null) }
    var selectedHourForNewTask by remember { mutableStateOf("08:00") }

    val dateTasks = allTasks.filter { it.plannedDate == selectedDate }
    val totalPlannedMinutes = dateTasks.sumOf { it.durationMinutes }
    val completedMinutes = dateTasks.filter { it.status == TaskStatus.COMPLETED }.sumOf { it.durationMinutes }

    // Hours between wake (e.g. 05:00) and sleep (e.g. 23:00)
    val wakeHour = userProfile?.wakeUpTime?.split(":")?.getOrNull(0)?.toIntOrNull() ?: 5
    val sleepHour = userProfile?.sleepTime?.split(":")?.getOrNull(0)?.toIntOrNull() ?: 23
    val totalAvailableMinutes = maxOf(60, (sleepHour - wakeHour) * 60)
    val freeMinutes = maxOf(0, totalAvailableMinutes - totalPlannedMinutes)

    val weekDates = remember(selectedDate) {
        val list = mutableListOf<String>()
        for (i in -3..3) {
            list.add(DateUtils.getDayOffset(selectedDate, i))
        }
        list
    }

    Box(modifier = modifier.fillMaxSize().background(ObsidianBlack)) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header
            Surface(
                color = SurfaceDark,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onNavigateBack) {
                            Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = FrostWhite)
                        }
                        Text(
                            text = "TIME-BLOCKED SCHEDULE",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.2.sp,
                                color = FrostWhite
                            )
                        )
                        IconButton(onClick = {
                            viewModel.setSelectedDate(DateUtils.todayString())
                        }) {
                            Icon(imageVector = Icons.Default.DateRange, contentDescription = "Today", tint = IcyBluePrimary)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Horizontal Week Days Strip
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(weekDates) { dateStr ->
                            val isSelected = dateStr == selectedDate
                            val isToday = dateStr == DateUtils.todayString()
                            Surface(
                                color = if (isSelected) IcyBluePrimary else SurfaceElevated,
                                shape = RoundedCornerShape(10.dp),
                                border = if (isToday && !isSelected) BorderStroke(1.dp, IcyBluePrimary) else null,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { viewModel.setSelectedDate(dateStr) }
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = dateStr.substring(8), // day of month
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) ObsidianBlack else FrostWhite
                                        )
                                    )
                                    Text(
                                        text = if (isToday) "TODAY" else dateStr.substring(5, 7),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (isSelected) ObsidianBlack else TextDim,
                                            fontSize = 9.sp
                                        )
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Day Load Metric Summary
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("PLANNED LOAD", style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 10.sp))
                            Text(
                                text = "${totalPlannedMinutes / 60}h ${totalPlannedMinutes % 60}m",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = FrostWhite)
                            )
                        }
                        Column {
                            Text("COMPLETED", style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 10.sp))
                            Text(
                                text = "${completedMinutes / 60}h ${completedMinutes % 60}m",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = SuccessGreen)
                            )
                        }
                        Column {
                            Text("FREE CAPACITY", style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 10.sp))
                            Text(
                                text = "${freeMinutes / 60}h ${freeMinutes % 60}m",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = IcyBlueLight)
                            )
                        }
                    }
                }
            }

            // Timeline hourly blocks list
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val startHour = minOf(wakeHour, 6)
                val endHour = maxOf(sleepHour, 22)

                for (hour in startHour..endHour) {
                    val hourStr = String.format("%02d:00", hour)
                    val nextHourStr = String.format("%02d:00", hour + 1)
                    val matchingTasks = dateTasks.filter {
                        val taskH = it.startTime.split(":").getOrNull(0)?.toIntOrNull()
                        taskH == hour
                    }

                    item(key = "hour_$hour") {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            // Hour Time label
                            Column(
                                modifier = Modifier.width(54.dp),
                                horizontalAlignment = Alignment.End
                            ) {
                                Text(
                                    text = hourStr,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = IcyBlueLight,
                                        fontSize = 11.sp
                                    )
                                )
                                Text(
                                    text = nextHourStr,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = TextDim,
                                        fontSize = 9.sp
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            // Hour slot content
                            Column(modifier = Modifier.weight(1f)) {
                                if (matchingTasks.isEmpty()) {
                                    // Empty slot placeholder
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(44.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(SurfaceDark.copy(alpha = 0.5f))
                                            .clickable {
                                                selectedHourForNewTask = hourStr
                                                selectedTaskForEdit = null
                                                showAddTaskSheet = true
                                            }
                                            .padding(horizontal = 12.dp),
                                        contentAlignment = Alignment.CenterStart
                                    ) {
                                        Text(
                                            text = "+ Block ${hourStr}",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = TextDim,
                                                fontSize = 11.sp
                                            )
                                        )
                                    }
                                } else {
                                    matchingTasks.forEach { task ->
                                        TaskCard(
                                            task = task,
                                            onComplete = { viewModel.completeTask(task.id) },
                                            onStart = { onEnterFocus(task.id) },
                                            onReschedule = { newDate -> viewModel.rescheduleTask(task.id, newDate) },
                                            onMarkMissed = { viewModel.markTaskMissed(task.id) },
                                            onDelete = { viewModel.deleteTask(task) },
                                            onClick = {
                                                selectedTaskForEdit = task
                                                showAddTaskSheet = true
                                            }
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(80.dp))
                }
            }
        }

        FloatingActionButton(
            onClick = {
                selectedHourForNewTask = "08:00"
                selectedTaskForEdit = null
                showAddTaskSheet = true
            },
            containerColor = IcyBluePrimary,
            contentColor = ObsidianBlack,
            shape = CircleShape,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "Add Time Block")
        }
    }

    if (showAddTaskSheet) {
        AddEditTaskBottomSheet(
            initialTask = selectedTaskForEdit,
            defaultDate = selectedDate,
            onDismiss = {
                showAddTaskSheet = false
                selectedTaskForEdit = null
            },
            onSave = { id, title, desc, cat, prio, date, st, et, dur, alarm, highAlert ->
                viewModel.saveTask(id, title, desc, cat, prio, date, st, et, dur, alarm, highAlert)
            }
        )
    }
}
