package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Update
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.TaskCategory
import com.example.data.local.entity.TaskEntity
import com.example.data.local.entity.TaskPriority
import com.example.data.local.entity.TaskStatus
import com.example.domain.DateUtils
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.CriticalRedBg
import com.example.ui.theme.FrostWhite
import com.example.ui.theme.IcyBlueLight
import com.example.ui.theme.IcyBluePrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceBorderSubtle
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WarningAmber

@Composable
fun TaskCard(
    task: TaskEntity,
    onComplete: () -> Unit,
    onStart: () -> Unit,
    onReschedule: (newDate: String) -> Unit,
    onMarkMissed: () -> Unit,
    onDelete: () -> Unit,
    onClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var showMenu by remember { mutableStateOf(false) }
    val isCompleted = task.status == TaskStatus.COMPLETED
    val isMissed = task.status == TaskStatus.MISSED
    val isActive = task.status == TaskStatus.ACTIVE

    val cardBorder = when {
        task.priority == TaskPriority.CRITICAL && !isCompleted -> BorderStroke(1.dp, CriticalRed.copy(alpha = 0.6f))
        isActive -> BorderStroke(1.dp, IcyBluePrimary)
        isMissed -> BorderStroke(1.dp, CriticalRed.copy(alpha = 0.4f))
        else -> BorderStroke(1.dp, SurfaceBorderSubtle)
    }

    val cardBg = when {
        isActive -> SurfaceElevated
        isMissed -> CriticalRedBg.copy(alpha = 0.2f)
        else -> SurfaceDark
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = cardBg),
        shape = RoundedCornerShape(14.dp),
        border = cardBorder,
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick?.invoke() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header: Category, Priority, Alarm & Menu
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CategoryBadge(category = task.category)
                    Spacer(modifier = Modifier.width(6.dp))
                    PriorityBadge(priority = task.priority)
                    if (task.isHighAlertEnabled) {
                        Spacer(modifier = Modifier.width(6.dp))
                        HighAlertBadge(stage = if (task.alarmStage > 0) task.alarmStage else 1)
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (task.isAlarmEnabled) {
                        Icon(
                            imageVector = Icons.Default.Alarm,
                            contentDescription = "Alarm Set",
                            tint = if (task.priority == TaskPriority.CRITICAL) CriticalRed else IcyBluePrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                    }
                    Box {
                        IconButton(
                            onClick = { showMenu = true },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "Options",
                                tint = TextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = showMenu,
                            onDismissRequest = { showMenu = false },
                            modifier = Modifier.background(SurfaceDark)
                        ) {
                            if (!isCompleted) {
                                DropdownMenuItem(
                                    text = { Text("Start Session", color = FrostWhite) },
                                    leadingIcon = { Icon(Icons.Default.PlayArrow, null, tint = IcyBluePrimary) },
                                    onClick = {
                                        showMenu = false
                                        onStart()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Mark as Missed", color = WarningAmber) },
                                    leadingIcon = { Icon(Icons.Default.Close, null, tint = WarningAmber) },
                                    onClick = {
                                        showMenu = false
                                        onMarkMissed()
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Reschedule to Tomorrow", color = FrostWhite) },
                                    leadingIcon = { Icon(Icons.Default.Update, null, tint = FrostWhite) },
                                    onClick = {
                                        showMenu = false
                                        onReschedule(DateUtils.getDayOffset(task.plannedDate, 1))
                                    }
                                )
                            }
                            DropdownMenuItem(
                                text = { Text("Delete Commitment", color = CriticalRed) },
                                onClick = {
                                    showMenu = false
                                    onDelete()
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Title & Description
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Status Toggle Circle
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(if (isCompleted) SuccessGreen else SurfaceElevated)
                        .clickable {
                            if (isCompleted) {
                                onStart()
                            } else {
                                onComplete()
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    if (isCompleted) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Completed",
                            tint = ObsidianBlack,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = task.title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isCompleted) TextDim else FrostWhite,
                            textDecoration = if (isCompleted) TextDecoration.LineThrough else null
                        ),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (task.description.isNotBlank()) {
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = task.description,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextMuted,
                                fontSize = 12.sp
                            ),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Footer: Time range, Duration, Rescheduled count warning
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (task.startTime.isNotBlank()) {
                        Text(
                            text = if (task.endTime.isNotBlank()) "${task.startTime} – ${task.endTime}" else task.startTime,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = IcyBlueLight,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "•",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextDim)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text(
                        text = "${task.durationMinutes} min",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextMuted)
                    )
                }

                if (task.rescheduledCount > 0) {
                    Text(
                        text = "Rescheduled ${task.rescheduledCount}x",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = WarningAmber,
                            fontWeight = FontWeight.Bold
                        )
                    )
                } else if (isActive) {
                    Surface(
                        color = IcyBluePrimary,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "IN PROGRESS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = ObsidianBlack,
                                fontWeight = FontWeight.Black
                            ),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}
