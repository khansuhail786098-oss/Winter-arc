package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.TaskCategory
import com.example.data.local.entity.TaskEntity
import com.example.data.local.entity.TaskPriority
import com.example.data.local.entity.TaskStatus
import com.example.domain.DateUtils
import com.example.domain.InsightType
import com.example.ui.MainViewModel
import com.example.ui.components.AddEditHabitBottomSheet
import com.example.ui.components.AddEditTaskBottomSheet
import com.example.ui.components.CategoryBadge
import com.example.ui.components.EmptyState
import com.example.ui.components.HighAlertBadge
import com.example.ui.components.MetricCardsGrid
import com.example.ui.components.OverallScoreCard
import com.example.ui.components.PriorityBadge
import com.example.ui.components.SectionHeader
import com.example.ui.components.TaskCard
import com.example.ui.components.WinterArcTopBar
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.CriticalRedBg
import com.example.ui.theme.FrostWhite
import com.example.ui.theme.IcyBlueDark
import com.example.ui.theme.IcyBlueLight
import com.example.ui.theme.IcyBluePrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceBorderSubtle
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberBg

@Composable
fun TodayScreen(
    viewModel: MainViewModel,
    onNavigateToPlanner: () -> Unit,
    onNavigateToFocus: (taskId: Long?) -> Unit,
    onNavigateToStudy: () -> Unit,
    onNavigateToWorkout: () -> Unit,
    onNavigateToAlarms: () -> Unit,
    onNavigateToNightReview: () -> Unit,
    onNavigateToGoals: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.todayUiState.collectAsState()
    var showAddTaskSheet by remember { mutableStateOf(false) }
    var showAddHabitSheet by remember { mutableStateOf(false) }
    var selectedTaskForEdit by remember { mutableStateOf<TaskEntity?>(null) }

    Box(modifier = modifier.fillMaxSize().background(ObsidianBlack)) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Top Bar
            item {
                WinterArcTopBar(
                    arcDayNumber = uiState.arcDayNumber,
                    currentDateDisplay = DateUtils.formatDisplayDate(uiState.selectedDate),
                    streakDays = uiState.currentStreakDays,
                    onSearchClick = onNavigateToPlanner,
                    onAlarmCenterClick = onNavigateToAlarms,
                    onStreakClick = onNavigateToNightReview
                )
            }

            // 2. Overdue / Backlog Banner (if any)
            if (uiState.overdueOrMissedTasks.isNotEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = WarningAmberBg.copy(alpha = 0.3f)),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateToPlanner() }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = "Warning",
                                    tint = WarningAmber,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "${uiState.overdueOrMissedTasks.size} COMMITMENTS REQUIRE ATTENTION",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Black,
                                            color = WarningAmber
                                        )
                                    )
                                    Text(
                                        text = "Overdue from previous blocks. Reschedule or resolve now.",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = TextMuted,
                                            fontSize = 11.sp
                                        )
                                    )
                                }
                            }
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = null,
                                tint = WarningAmber,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            // 3. Overall Completion Score Card
            item {
                OverallScoreCard(
                    score = uiState.todayScore.totalScore,
                    subtitle = "DAY ${uiState.arcDayNumber} EXECUTION SCORE"
                )
            }

            // 4. Active Directive / Hero Focus Block
            item {
                val currentTask = uiState.activeTask
                if (currentTask != null) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (currentTask.priority == TaskPriority.CRITICAL) CriticalRedBg.copy(alpha = 0.25f) else SurfaceElevated
                        ),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(
                            1.dp,
                            if (currentTask.priority == TaskPriority.CRITICAL) CriticalRed else IcyBluePrimary
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CategoryBadge(category = currentTask.category)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    PriorityBadge(priority = currentTask.priority)
                                }
                                Surface(
                                    color = IcyBluePrimary.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = "NEXT COMMITMENT",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Black,
                                            color = IcyBlueLight
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = currentTask.title,
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = FrostWhite
                                )
                            )

                            if (currentTask.description.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = currentTask.description,
                                    style = MaterialTheme.typography.bodyMedium.copy(color = TextMuted)
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${currentTask.startTime} • ${currentTask.durationMinutes} min block",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        color = IcyBlueLight,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )

                                Surface(
                                    color = IcyBluePrimary,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { onNavigateToFocus(currentTask.id) }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.PlayArrow,
                                            contentDescription = null,
                                            tint = ObsidianBlack,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "ENTER FOCUS",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Black,
                                                color = ObsidianBlack
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 5. Core Metric Cards Grid
            item {
                MetricCardsGrid(
                    studyMinutes = uiState.todayStudyMinutes,
                    studyTargetMinutes = uiState.userProfile.dailyStudyTargetMinutes,
                    workMinutes = uiState.todayWorkMinutes,
                    workTargetMinutes = uiState.userProfile.dailyWorkTargetMinutes,
                    workoutMinutes = uiState.todayWorkoutMinutes,
                    workoutTargetMinutes = uiState.userProfile.dailyWorkoutTargetMinutes,
                    habitsCompleted = uiState.todayHabitsCompleted,
                    habitsTotal = uiState.todayHabitsTotal,
                    onStudyClick = onNavigateToStudy,
                    onWorkClick = onNavigateToPlanner,
                    onWorkoutClick = onNavigateToWorkout,
                    onHabitsClick = { showAddHabitSheet = true }
                )
            }

            // 6. Productivity Insights & Rule Warnings
            if (uiState.insights.isNotEmpty()) {
                item {
                    val insight = uiState.insights.first()
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, SurfaceBorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            val iconColor = when (insight.type) {
                                InsightType.POSITIVE -> SuccessGreen
                                InsightType.ATTENTION -> WarningAmber
                                InsightType.WARNING -> CriticalRed
                                InsightType.INFO -> IcyBluePrimary
                            }
                            Icon(
                                imageVector = if (insight.type == InsightType.WARNING) Icons.Default.Warning else Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = iconColor,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = insight.title,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = FrostWhite
                                    )
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = insight.description,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = TextMuted,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // 7. Today's Scheduled Commitments
            item {
                SectionHeader(
                    title = "Daily Commitments",
                    subtitle = "${uiState.tasks.count { it.status == TaskStatus.COMPLETED }}/${uiState.tasks.size} Completed",
                    actionText = "+ Add Block",
                    onActionClick = { showAddTaskSheet = true }
                )
            }

            if (uiState.tasks.isEmpty()) {
                item {
                    EmptyState(
                        title = "No Commitments Scheduled",
                        message = "Plan your blocks to lock in your discipline for Day ${uiState.arcDayNumber}.",
                        buttonText = "Plan Day Schedule",
                        onButtonClick = { showAddTaskSheet = true }
                    )
                }
            } else {
                items(uiState.tasks, key = { it.id }) { task ->
                    TaskCard(
                        task = task,
                        onComplete = { viewModel.completeTask(task.id) },
                        onStart = { onNavigateToFocus(task.id) },
                        onReschedule = { newDate -> viewModel.rescheduleTask(task.id, newDate) },
                        onMarkMissed = { viewModel.markTaskMissed(task.id) },
                        onDelete = { viewModel.deleteTask(task) },
                        onClick = {
                            selectedTaskForEdit = task
                            showAddTaskSheet = true
                        }
                    )
                }
            }

            // 8. Daily Habits Checklist
            item {
                SectionHeader(
                    title = "Daily Habits Protocol",
                    subtitle = "Unbroken Streaks & Discipline Checks",
                    actionText = "+ Add Habit",
                    onActionClick = { showAddHabitSheet = true }
                )
            }

            if (uiState.habits.isEmpty()) {
                item {
                    EmptyState(
                        title = "No Daily Habits Added",
                        message = "Define non-negotiable daily habits (e.g., Early Wake, Cold Shower, No Sugar).",
                        buttonText = "+ Add Habit Protocol",
                        onButtonClick = { showAddHabitSheet = true }
                    )
                }
            } else {
                items(uiState.habits, key = { it.id }) { habit ->
                    val isCompleted = uiState.habitLogs.any { it.habitId == habit.id && it.isCompleted }
                    HabitRowItem(
                        habit = habit,
                        isCompleted = isCompleted,
                        onToggle = { viewModel.toggleHabit(habit.id, uiState.selectedDate) }
                    )
                }
            }

            // 9. Master Goal & Countdowns Banner
            if (uiState.countdowns.isNotEmpty()) {
                item {
                    SectionHeader(
                        title = "Target Countdowns",
                        actionText = "View Goals",
                        onActionClick = onNavigateToGoals
                    )
                }
                items(uiState.countdowns.take(2), key = { it.id }) { countdown ->
                    val remainingDays = DateUtils.getRemainingDaysUntil(countdown.targetDate)
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, SurfaceBorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = countdown.title,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = FrostWhite
                                    )
                                )
                                Text(
                                    text = "Target Date: ${DateUtils.formatShortDisplayDate(countdown.targetDate)}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextDim, fontSize = 11.sp)
                                )
                            }
                            Surface(
                                color = IcyBluePrimary.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, IcyBluePrimary.copy(alpha = 0.4f))
                            ) {
                                Text(
                                    text = "$remainingDays DAYS LEFT",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Black,
                                        color = IcyBlueLight
                                    ),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            // 10. Nightly Review CTA Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, IcyBluePrimary.copy(alpha = 0.3f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToNightReview() }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "NIGHTLY PROTOCOL REVIEW",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.sp,
                                    color = IcyBluePrimary
                                )
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Log Day ${uiState.arcDayNumber} metrics and prepare tomorrow's plan.",
                                style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = null,
                            tint = IcyBluePrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        // Floating Action Button for Quick Task Creation
        FloatingActionButton(
            onClick = {
                selectedTaskForEdit = null
                showAddTaskSheet = true
            },
            containerColor = IcyBluePrimary,
            contentColor = ObsidianBlack,
            shape = CircleShape,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(bottom = 20.dp, end = 20.dp)
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "Add Commitment")
        }
    }

    if (showAddTaskSheet) {
        AddEditTaskBottomSheet(
            initialTask = selectedTaskForEdit,
            defaultDate = uiState.selectedDate,
            onDismiss = {
                showAddTaskSheet = false
                selectedTaskForEdit = null
            },
            onSave = { id, title, desc, cat, prio, date, st, et, dur, alarm, highAlert ->
                viewModel.saveTask(id, title, desc, cat, prio, date, st, et, dur, alarm, highAlert)
            }
        )
    }

    if (showAddHabitSheet) {
        AddEditHabitBottomSheet(
            onDismiss = { showAddHabitSheet = false },
            onSave = { name, icon, targetDays, time ->
                viewModel.saveHabit(name = name, iconName = icon, targetDaysPerWeek = targetDays, reminderTime = time)
            }
        )
    }
}

@Composable
fun HabitRowItem(
    habit: HabitEntity,
    isCompleted: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isCompleted) SurfaceDark.copy(alpha = 0.6f) else SurfaceDark
        ),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, if (isCompleted) SuccessGreen.copy(alpha = 0.3f) else SurfaceBorderSubtle),
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable { onToggle() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(if (isCompleted) SuccessGreen else SurfaceElevated),
                    contentAlignment = Alignment.Center
                ) {
                    if (isCompleted) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Completed",
                            tint = ObsidianBlack,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = habit.name,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = if (isCompleted) TextMuted else FrostWhite
                        )
                    )
                    if (habit.reminderTime.isNotBlank()) {
                        Text(
                            text = "Reminder: ${habit.reminderTime}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = TextDim,
                                fontSize = 10.sp
                            )
                        )
                    }
                }
            }

            Surface(
                color = WarningAmber.copy(alpha = 0.12f),
                shape = RoundedCornerShape(6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.LocalFireDepartment,
                        contentDescription = null,
                        tint = WarningAmber,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "${habit.currentStreak}d",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = WarningAmber
                        )
                    )
                }
            }
        }
    }
}
