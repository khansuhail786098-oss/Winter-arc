package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.DailyScoreEntity
import com.example.data.local.entity.TaskStatus
import com.example.domain.DateUtils
import com.example.ui.MainViewModel
import com.example.ui.components.EmptyState
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.CriticalRedBg
import com.example.ui.theme.FrostWhite
import com.example.ui.theme.IcyBlueDark
import com.example.ui.theme.IcyBlueLight
import com.example.ui.theme.IcyBluePrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceBorderSubtle
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WarningAmber
import com.example.ui.theme.WarningAmberBg

@Composable
fun AnalyticsScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val dailyScores by viewModel.allDailyScores.collectAsState()
    val allTasks by viewModel.allTasks.collectAsState()
    val studySessions by viewModel.allStudySessions.collectAsState()
    val workoutSessions by viewModel.allWorkoutSessions.collectAsState()

    val averageScore = if (dailyScores.isNotEmpty()) dailyScores.map { it.totalScore }.average().toInt() else 0
    val totalStudyHours = (studySessions.sumOf { it.durationMinutes } +
            allTasks.filter { it.category.name == "STUDY" && it.status == TaskStatus.COMPLETED }.sumOf { it.durationMinutes }) / 60
    val totalWorkoutHours = (workoutSessions.sumOf { it.durationMinutes } +
            allTasks.filter { it.category.name == "WORKOUT" && it.status == TaskStatus.COMPLETED }.sumOf { it.durationMinutes }) / 60

    val heavilyRescheduledTasks = allTasks.filter { it.rescheduledCount > 0 }
    val missedTasks = allTasks.filter { it.status == TaskStatus.MISSED }

    Box(modifier = modifier.fillMaxSize().background(ObsidianBlack)) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = FrostWhite)
                    }
                    Text(
                        text = "ANALYTICS & DISCIPLINE AUDIT",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.2.sp,
                            color = FrostWhite
                        )
                    )
                    Spacer(modifier = Modifier.width(48.dp))
                }
            }

            // High Level Discipline Metric Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, SurfaceBorderSubtle),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("ARC AVG SCORE", style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 10.sp))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("$averageScore%", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black, color = IcyBlueLight))
                        }
                    }
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, SurfaceBorderSubtle),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("TOTAL STUDY", style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 10.sp))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("${totalStudyHours}h", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black, color = FrostWhite))
                        }
                    }
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, SurfaceBorderSubtle),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("TOTAL WORKOUT", style = MaterialTheme.typography.labelSmall.copy(color = TextDim, fontSize = 10.sp))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("${totalWorkoutHours}h", style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black, color = SuccessGreen))
                        }
                    }
                }
            }

            // 7-Day Performance Canvas Bar Chart
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, SurfaceBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "7-DAY DISCIPLINE TREND",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 1.2.sp,
                                    color = FrostWhite
                                )
                            )
                            Text(
                                text = "Score / 100",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextDim)
                            )
                        }

                        Spacer(modifier = Modifier.height(18.dp))

                        // Custom 7-Day Bar Chart
                        val past7Days = DateUtils.getPastWeekDates()
                        val scoresMap = dailyScores.associateBy { it.date }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val canvasWidth = size.width
                                val canvasHeight = size.height
                                val barWidth = 24.dp.toPx()
                                val spacing = (canvasWidth - (barWidth * 7)) / 8

                                past7Days.forEachIndexed { index, dateStr ->
                                    val score = scoresMap[dateStr]?.totalScore ?: 0
                                    val trackHeight = canvasHeight - 30.dp.toPx()
                                    val x = spacing + (index * (barWidth + spacing))
                                    val yTrack = 10.dp.toPx()

                                    // Subtle background track
                                    drawRoundRect(
                                        color = SurfaceBorderSubtle,
                                        topLeft = Offset(x, yTrack),
                                        size = Size(barWidth, trackHeight),
                                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                                    )

                                    if (score > 0) {
                                        val barHeight = (score / 100f) * trackHeight
                                        val y = canvasHeight - 20.dp.toPx() - barHeight

                                        // Filled Bar
                                        drawRoundRect(
                                            color = if (score >= 80) IcyBluePrimary else if (score >= 60) WarningAmber else CriticalRed,
                                            topLeft = Offset(x, y),
                                            size = Size(barWidth, barHeight),
                                            cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx())
                                        )
                                    }
                                }
                            }

                            // Day labels below
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .align(Alignment.BottomCenter),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                past7Days.forEach { dateStr ->
                                    val shortDate = dateStr.substring(8) // Day number
                                    Text(
                                        text = shortDate,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = TextDim,
                                            fontSize = 10.sp
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Anti-Procrastination / Rescheduled Task Audit Card
            item {
                SectionHeader(
                    title = "Avoidance & Reschedule Audit",
                    subtitle = "Tasks delayed multiple times indicate resistance points"
                )
            }

            if (heavilyRescheduledTasks.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, SurfaceBorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Zero avoidance detected. All commitments are executed on initial schedule.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = SuccessGreen),
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                }
            } else {
                items(heavilyRescheduledTasks, key = { it.id }) { task ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = task.title,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = FrostWhite
                                    )
                                )
                                Text(
                                    text = "Current Date: ${task.plannedDate} (${task.category.name})",
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 11.sp)
                                )
                            }
                            Surface(
                                color = WarningAmberBg,
                                shape = RoundedCornerShape(6.dp),
                                border = BorderStroke(1.dp, WarningAmber)
                            ) {
                                Text(
                                    text = "RESCHEDULED ${task.rescheduledCount}x",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Black,
                                        color = WarningAmber
                                    ),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Missed Commitments List (if any)
            if (missedTasks.isNotEmpty()) {
                item {
                    SectionHeader(
                        title = "Missed Commitments",
                        subtitle = "Honest accountability log"
                    )
                }
                items(missedTasks, key = { it.id }) { task ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CriticalRedBg.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, CriticalRed.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = task.title,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = FrostWhite
                                    )
                                )
                                Text(
                                    text = "Missed on ${task.plannedDate}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextMuted, fontSize = 11.sp)
                                )
                            }
                            Surface(
                                color = CriticalRed,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "MISSED",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Black,
                                        color = ObsidianBlack
                                    ),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}
