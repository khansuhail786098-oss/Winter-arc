package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.alarm.NotificationHelper
import com.example.data.local.entity.TaskEntity
import com.example.data.local.entity.TaskPriority
import com.example.domain.DateUtils
import com.example.ui.MainViewModel
import com.example.ui.components.CategoryBadge
import com.example.ui.components.EmptyState
import com.example.ui.components.HighAlertBadge
import com.example.ui.components.PrimaryButton
import com.example.ui.components.PriorityBadge
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.CriticalRedBg
import com.example.ui.theme.FrostWhite
import com.example.ui.theme.IcyBlueLight
import com.example.ui.theme.IcyBluePrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceBorderSubtle
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WarningAmber

@Composable
fun AlarmScreen(
    viewModel: MainViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val allTasks by viewModel.allTasks.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()
    val today = DateUtils.todayString()

    val alarmTasks = allTasks.filter { it.isAlarmEnabled && it.plannedDate >= today }
    var testTriggeredMessage by remember { mutableStateOf<String?>(null) }

    Box(modifier = modifier.fillMaxSize().background(ObsidianBlack)) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = FrostWhite)
                    }
                    Text(
                        text = "ALARM & HIGH ALERT CENTER",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.2.sp,
                            color = FrostWhite
                        )
                    )
                    Spacer(modifier = Modifier.width(48.dp))
                }
            }

            // Morning Wake & Sleep Schedule Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, SurfaceBorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "WAKE & SLEEP CADENCE",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.5.sp,
                                    color = IcyBlueLight
                                )
                            )
                            Icon(imageVector = Icons.Default.Alarm, contentDescription = null, tint = IcyBluePrimary)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("WAKE UP ALARM", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                                Text(
                                    text = userProfile?.wakeUpTime ?: "05:30 AM",
                                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black, color = FrostWhite)
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("SLEEP PROTOCOL", style = MaterialTheme.typography.labelSmall.copy(color = TextDim))
                                Text(
                                    text = userProfile?.sleepTime ?: "10:30 PM",
                                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Black, color = FrostWhite)
                                )
                            }
                        }
                    }
                }
            }

            // 5-Stage High Alert Escalation Architecture Explainer Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceElevated),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, CriticalRed.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = CriticalRed)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "HIGH ALERT ESCALATION PROTOCOL",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Black,
                                        letterSpacing = 1.sp,
                                        color = CriticalRed
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        val stages = listOf(
                            Pair("Stage 1", "Scheduled Commitment Reminder (Gentle notification)"),
                            Pair("Stage 2", "Persistent Alert (+5 min if unacknowledged)"),
                            Pair("Stage 3", "High-Priority Audible Alarm (+10 min)"),
                            Pair("Stage 4", "Audible Alarm Loop with Vibration (+15 min)"),
                            Pair("Stage 5", "Near-Miss Flag & Daily Score Penalty Logged")
                        )

                        stages.forEachIndexed { index, (stageName, stageDesc) ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Surface(
                                    color = if (index >= 2) CriticalRed else IcyBluePrimary,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = stageName,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Black,
                                            color = ObsidianBlack,
                                            fontSize = 9.sp
                                        ),
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = stageDesc,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = if (index >= 2) FrostWhite else TextMuted,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // Active Scheduled Alarms List
            item {
                SectionHeader(
                    title = "Active Alarms Queue",
                    subtitle = "${alarmTasks.size} Scheduled Exact Alarms"
                )
            }

            if (alarmTasks.isEmpty()) {
                item {
                    EmptyState(
                        title = "No Alarms Scheduled",
                        message = "Enable alarms when adding tasks to activate exact sound triggers."
                    )
                }
            } else {
                items(alarmTasks, key = { it.id }) { task ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            1.dp,
                            if (task.priority == TaskPriority.CRITICAL) CriticalRed.copy(alpha = 0.5f) else SurfaceBorderSubtle
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CategoryBadge(category = task.category)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    PriorityBadge(priority = task.priority)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = task.title,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = FrostWhite
                                    )
                                )
                                Text(
                                    text = "${task.plannedDate} at ${task.startTime}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = IcyBlueLight,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                            }

                            Switch(
                                checked = task.isAlarmEnabled,
                                onCheckedChange = { isEnabled ->
                                    viewModel.saveTask(
                                        id = task.id,
                                        title = task.title,
                                        description = task.description,
                                        category = task.category,
                                        priority = task.priority,
                                        plannedDate = task.plannedDate,
                                        startTime = task.startTime,
                                        endTime = task.endTime,
                                        durationMinutes = task.durationMinutes,
                                        isAlarmEnabled = isEnabled,
                                        isHighAlertEnabled = task.isHighAlertEnabled
                                    )
                                },
                                colors = SwitchDefaults.colors(checkedThumbColor = IcyBluePrimary)
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}
