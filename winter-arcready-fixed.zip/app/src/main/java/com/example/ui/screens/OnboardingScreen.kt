package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.DateUtils
import com.example.ui.MainViewModel
import com.example.ui.components.PrimaryButton
import com.example.ui.components.SecondaryButton
import com.example.ui.theme.FrostWhite
import com.example.ui.theme.IcyBlueLight
import com.example.ui.theme.IcyBluePrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PurpleAccent
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceBorderSubtle
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted

@Composable
fun OnboardingScreen(
    viewModel: MainViewModel,
    onFinishOnboarding: () -> Unit,
    modifier: Modifier = Modifier
) {
    var step by remember { mutableIntStateOf(1) }

    var name by remember { mutableStateOf("Arc Commander") }
    var wakeUpTime by remember { mutableStateOf("05:30") }
    var sleepTime by remember { mutableStateOf("22:30") }
    var studyHours by remember { mutableStateOf("6") }
    var workoutMinutes by remember { mutableStateOf("60") }
    var workHours by remember { mutableStateOf("3") }
    var arcName by remember { mutableStateOf("WINTER ARC 2026") }
    var mainObjective by remember { mutableStateOf("Become undeniable in academics, physical strength, and daily execution.") }
    var primaryGoalTitle by remember { mutableStateOf("Master Physics & Competitive Syllabus") }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBlack)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Step Progress Indicator
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                (1..4).forEach { i ->
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 4.dp)
                            .width(60.dp)
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(if (i <= step) IcyBluePrimary else SurfaceElevated)
                    )
                }
            }

            // Step Content
            when (step) {
                1 -> {
                    // Philosophy & Welcome
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(SurfaceDark),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.AcUnit, contentDescription = null, tint = IcyBluePrimary, modifier = Modifier.size(36.dp))
                        }
                        Spacer(modifier = Modifier.height(20.dp))
                        Text(
                            text = "THE WINTER ARC",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 3.sp,
                                color = FrostWhite
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "A personal operating system for relentless discipline, study, fitness, scheduling, and uncompromising execution.",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = TextMuted,
                                fontSize = 14.sp,
                                lineHeight = 20.sp
                            ),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Card(
                            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, SurfaceBorderSubtle),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("CORE PROTOCOL", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = IcyBlueLight, letterSpacing = 1.sp))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("PLAN → EXECUTE → TRACK → ANALYZE → IMPROVE", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Black, color = FrostWhite))
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("Your Call-Sign / Name") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = IcyBluePrimary,
                                unfocusedBorderColor = SurfaceBorder,
                                focusedTextColor = FrostWhite,
                                unfocusedTextColor = FrostWhite
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                2 -> {
                    // Sleep & Wake Cadence
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Alarm, contentDescription = null, tint = IcyBluePrimary, modifier = Modifier.size(44.dp))
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "WAKE & SLEEP DISCIPLINE",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.5.sp,
                                color = FrostWhite
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Master your morning. No snoozing, no excuses.",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        OutlinedTextField(
                            value = wakeUpTime,
                            onValueChange = { wakeUpTime = it },
                            label = { Text("Wake-up Time (HH:mm)") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        OutlinedTextField(
                            value = sleepTime,
                            onValueChange = { sleepTime = it },
                            label = { Text("Bedtime / Sleep (HH:mm)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                3 -> {
                    // Daily Target Allocations
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.MenuBook, contentDescription = null, tint = IcyBluePrimary, modifier = Modifier.size(44.dp))
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "DAILY TARGET ALLOCATIONS",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.5.sp,
                                color = FrostWhite
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Define daily non-negotiable target hours.",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        OutlinedTextField(
                            value = studyHours,
                            onValueChange = { studyHours = it },
                            label = { Text("Daily Study Target (Hours)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = workoutMinutes,
                            onValueChange = { workoutMinutes = it },
                            label = { Text("Daily Workout Target (Minutes)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = workHours,
                            onValueChange = { workHours = it },
                            label = { Text("Daily Work/Projects Target (Hours)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                4 -> {
                    // Arc Directive & Primary Goal
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = IcyBluePrimary, modifier = Modifier.size(44.dp))
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "THE 90-DAY MISSION",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.5.sp,
                                color = FrostWhite
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Declare your master objective for this Winter Arc.",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextMuted)
                        )

                        Spacer(modifier = Modifier.height(20.dp))

                        OutlinedTextField(
                            value = arcName,
                            onValueChange = { arcName = it },
                            label = { Text("Arc Protocol Name") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = mainObjective,
                            onValueChange = { mainObjective = it },
                            label = { Text("Master 90-Day Directive") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = primaryGoalTitle,
                            onValueChange = { primaryGoalTitle = it },
                            label = { Text("Primary #1 Academic / Fitness Goal") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Bottom Navigation Actions
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (step > 1) {
                    SecondaryButton(
                        text = "BACK",
                        onClick = { step -= 1 },
                        modifier = Modifier.weight(1f)
                    )
                }

                PrimaryButton(
                    text = if (step < 4) "CONTINUE" else "COMMENCE WINTER ARC",
                    icon = if (step < 4) Icons.Default.ArrowForward else Icons.Default.Check,
                    onClick = {
                        if (step < 4) {
                            step += 1
                        } else {
                            val today = DateUtils.todayString()
                            val endDate = DateUtils.getDayOffset(today, 90)
                            viewModel.saveOnboardingProfile(
                                name = name,
                                age = 22,
                                wakeUpTime = wakeUpTime,
                                sleepTime = sleepTime,
                                studyHours = studyHours.toIntOrNull() ?: 6,
                                workoutMinutes = workoutMinutes.toIntOrNull() ?: 60,
                                workHours = workHours.toIntOrNull() ?: 3,
                                arcName = arcName,
                                mainObjective = mainObjective,
                                startDate = today,
                                endDate = endDate,
                                primaryGoalTitle = primaryGoalTitle,
                                primaryGoalCategory = "Academics"
                            )
                            onFinishOnboarding()
                        }
                    },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
