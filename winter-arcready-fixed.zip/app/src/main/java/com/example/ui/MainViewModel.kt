package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.WinterArcApp
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.CountdownEntity
import com.example.data.local.entity.DailyReviewEntity
import com.example.data.local.entity.DailyScoreEntity
import com.example.data.local.entity.ExerciseEntity
import com.example.data.local.entity.FocusSessionEntity
import com.example.data.local.entity.GoalEntity
import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.HabitLogEntity
import com.example.data.local.entity.MilestoneEntity
import com.example.data.local.entity.ProjectEntity
import com.example.data.local.entity.StudyChapterEntity
import com.example.data.local.entity.StudyRevisionEntity
import com.example.data.local.entity.StudySessionEntity
import com.example.data.local.entity.StudySubjectEntity
import com.example.data.local.entity.StudyTopicEntity
import com.example.data.local.entity.TaskCategory
import com.example.data.local.entity.TaskEntity
import com.example.data.local.entity.TaskPriority
import com.example.data.local.entity.TaskStatus
import com.example.data.local.entity.UserProfileEntity
import com.example.data.local.entity.WinterArcEntity
import com.example.data.local.entity.WorkoutRoutineEntity
import com.example.data.local.entity.WorkoutSessionEntity
import com.example.domain.DateUtils
import com.example.domain.ProductivityInsight
import com.example.domain.ProductivityInsightsEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class TodayUiState(
    val userProfile: UserProfileEntity = UserProfileEntity(),
    val winterArc: WinterArcEntity = WinterArcEntity(),
    val arcDayNumber: Int = 1,
    val selectedDate: String = DateUtils.todayString(),
    val todayScore: DailyScoreEntity = DailyScoreEntity(date = DateUtils.todayString()),
    val tasks: List<TaskEntity> = emptyList(),
    val habits: List<HabitEntity> = emptyList(),
    val habitLogs: List<HabitLogEntity> = emptyList(),
    val activeTask: TaskEntity? = null,
    val overdueOrMissedTasks: List<TaskEntity> = emptyList(),
    val currentStreakDays: Int = 0,
    val todayStudyMinutes: Int = 0,
    val todayWorkMinutes: Int = 0,
    val todayWorkoutMinutes: Int = 0,
    val todayHabitsCompleted: Int = 0,
    val todayHabitsTotal: Int = 0,
    val insights: List<ProductivityInsight> = emptyList(),
    val pendingRevisions: List<StudyRevisionEntity> = emptyList(),
    val countdowns: List<CountdownEntity> = emptyList(),
    val isLoading: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as WinterArcApp).repository

    private val _selectedDate = MutableStateFlow(DateUtils.todayString())
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Global entities state flows
    val userProfile: StateFlow<UserProfileEntity?> = repository.userProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val winterArc: StateFlow<WinterArcEntity?> = repository.winterArc
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val appSettings: StateFlow<AppSettingsEntity?> = repository.appSettings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allTasks: StateFlow<List<TaskEntity>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allHabits: StateFlow<List<HabitEntity>> = repository.allHabits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allGoals: StateFlow<List<GoalEntity>> = repository.allGoals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allProjects: StateFlow<List<ProjectEntity>> = repository.allProjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSubjects: StateFlow<List<StudySubjectEntity>> = repository.allSubjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allStudySessions: StateFlow<List<StudySessionEntity>> = repository.allStudySessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pendingRevisions: StateFlow<List<StudyRevisionEntity>> = repository.pendingRevisions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allWorkoutRoutines: StateFlow<List<WorkoutRoutineEntity>> = repository.allWorkoutRoutines
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allWorkoutSessions: StateFlow<List<WorkoutSessionEntity>> = repository.allWorkoutSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allDailyScores: StateFlow<List<DailyScoreEntity>> = repository.allDailyScores
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCountdowns: StateFlow<List<CountdownEntity>> = repository.allCountdowns
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Aggregated Today UI State
    val todayUiState: StateFlow<TodayUiState> = combine(
        _selectedDate,
        userProfile,
        winterArc,
        allTasks,
        allHabits,
        allDailyScores,
        pendingRevisions,
        allCountdowns,
        allStudySessions
    ) { args: Array<Any?> ->
        val date = args[0] as String
        val profile = (args[1] as? UserProfileEntity) ?: UserProfileEntity()
        val arc = (args[2] as? WinterArcEntity) ?: WinterArcEntity()
        @Suppress("UNCHECKED_CAST")
        val tasks = (args[3] as? List<TaskEntity>) ?: emptyList()
        @Suppress("UNCHECKED_CAST")
        val habits = (args[4] as? List<HabitEntity>) ?: emptyList()
        @Suppress("UNCHECKED_CAST")
        val scores = (args[5] as? List<DailyScoreEntity>) ?: emptyList()
        @Suppress("UNCHECKED_CAST")
        val revisions = (args[6] as? List<StudyRevisionEntity>) ?: emptyList()
        @Suppress("UNCHECKED_CAST")
        val countdowns = (args[7] as? List<CountdownEntity>) ?: emptyList()
        @Suppress("UNCHECKED_CAST")
        val studySessions = (args[8] as? List<StudySessionEntity>) ?: emptyList()

        val dateTasks = tasks.filter { it.plannedDate == date }
        val dateScore = scores.find { it.date == date } ?: DailyScoreEntity(date = date)

        val activeTask = dateTasks.find { it.status == TaskStatus.ACTIVE }
            ?: dateTasks.find { it.status == TaskStatus.PLANNED }

        val missedOrOverdue = tasks.filter {
            (it.plannedDate < date && it.status == TaskStatus.PLANNED) ||
                    (it.plannedDate == date && it.status == TaskStatus.MISSED)
        }

        val arcDay = DateUtils.calculateArcDayNumber(arc.startDate)
        val insights = ProductivityInsightsEngine.generateInsights(tasks, scores, studySessions)

        val studyMinutes = dateTasks.filter { it.category == TaskCategory.STUDY && it.status == TaskStatus.COMPLETED }.sumOf { it.durationMinutes }
        val workMinutes = dateTasks.filter { it.category == TaskCategory.WORK && it.status == TaskStatus.COMPLETED }.sumOf { it.durationMinutes }
        val workoutMinutes = dateTasks.filter { it.category == TaskCategory.WORKOUT && it.status == TaskStatus.COMPLETED }.sumOf { it.durationMinutes }

        TodayUiState(
            userProfile = profile,
            winterArc = arc,
            arcDayNumber = arcDay,
            selectedDate = date,
            todayScore = dateScore,
            tasks = dateTasks,
            habits = habits,
            activeTask = activeTask,
            overdueOrMissedTasks = missedOrOverdue,
            currentStreakDays = habits.maxOfOrNull { it.currentStreak } ?: 0,
            todayStudyMinutes = studyMinutes,
            todayWorkMinutes = workMinutes,
            todayWorkoutMinutes = workoutMinutes,
            todayHabitsCompleted = dateScore.habitsCompleted,
            todayHabitsTotal = habits.size,
            insights = insights,
            pendingRevisions = revisions,
            countdowns = countdowns,
            isLoading = false
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), TodayUiState())

    fun setSelectedDate(date: String) {
        _selectedDate.value = date
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun completeTask(taskId: Long) {
        viewModelScope.launch {
            repository.updateTaskStatus(taskId, TaskStatus.COMPLETED)
        }
    }

    fun startTask(taskId: Long) {
        viewModelScope.launch {
            repository.updateTaskStatus(taskId, TaskStatus.ACTIVE)
        }
    }

    fun markTaskMissed(taskId: Long) {
        viewModelScope.launch {
            repository.updateTaskStatus(taskId, TaskStatus.MISSED)
        }
    }

    fun skipTask(taskId: Long) {
        viewModelScope.launch {
            repository.updateTaskStatus(taskId, TaskStatus.SKIPPED)
        }
    }

    fun rescheduleTask(taskId: Long, newDate: String) {
        viewModelScope.launch {
            repository.rescheduleTask(taskId, newDate)
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.deleteTask(task)
        }
    }

    fun saveTask(
        id: Long = 0L,
        title: String,
        description: String,
        category: TaskCategory,
        priority: TaskPriority,
        plannedDate: String,
        startTime: String,
        endTime: String,
        durationMinutes: Int,
        isAlarmEnabled: Boolean,
        isHighAlertEnabled: Boolean
    ) {
        viewModelScope.launch {
            val task = TaskEntity(
                id = id,
                title = title,
                description = description,
                category = category,
                priority = priority,
                status = TaskStatus.PLANNED,
                plannedDate = plannedDate,
                startTime = startTime,
                endTime = endTime,
                durationMinutes = durationMinutes,
                isAlarmEnabled = isAlarmEnabled,
                isHighAlertEnabled = isHighAlertEnabled
            )
            if (id > 0) {
                repository.updateTask(task)
            } else {
                repository.insertTask(task)
            }
        }
    }

    fun toggleHabit(habitId: Long, date: String = _selectedDate.value) {
        viewModelScope.launch {
            repository.toggleHabitCompletion(habitId, date)
        }
    }

    fun saveHabit(id: Long = 0L, name: String, iconName: String, targetDaysPerWeek: Int, reminderTime: String) {
        viewModelScope.launch {
            val habit = HabitEntity(
                id = id,
                name = name,
                iconName = iconName,
                targetDaysPerWeek = targetDaysPerWeek,
                reminderTime = reminderTime
            )
            if (id > 0) repository.updateHabit(habit) else repository.insertHabit(habit)
        }
    }

    fun deleteHabit(habit: HabitEntity) {
        viewModelScope.launch { repository.deleteHabit(habit) }
    }

    fun saveGoal(id: Long = 0L, title: String, description: String, category: String, priority: TaskPriority, deadline: String, progress: Int) {
        viewModelScope.launch {
            val goal = GoalEntity(
                id = id,
                title = title,
                description = description,
                category = category,
                priority = priority,
                deadline = deadline,
                progressPercent = progress
            )
            if (id > 0) repository.updateGoal(goal) else repository.insertGoal(goal)
        }
    }

    fun deleteGoal(goal: GoalEntity) {
        viewModelScope.launch { repository.deleteGoal(goal) }
    }

    fun saveProject(id: Long = 0L, name: String, description: String, deadline: String, priority: TaskPriority, progress: Int) {
        viewModelScope.launch {
            val project = ProjectEntity(
                id = id,
                name = name,
                description = description,
                deadline = deadline,
                priority = priority,
                progressPercent = progress
            )
            if (id > 0) repository.updateProject(project) else repository.insertProject(project)
        }
    }

    fun deleteProject(project: ProjectEntity) {
        viewModelScope.launch { repository.deleteProject(project) }
    }

    fun logStudySession(subjectName: String, chapterTitle: String, topicTitle: String, durationMinutes: Int, notes: String) {
        viewModelScope.launch {
            repository.logStudySession(
                StudySessionEntity(
                    subjectName = subjectName,
                    chapterTitle = chapterTitle,
                    topicTitle = topicTitle,
                    durationMinutes = durationMinutes,
                    date = DateUtils.todayString(),
                    notes = notes
                )
            )
        }
    }

    fun createStudySubject(name: String, targetHours: Int, chapters: List<String>) {
        viewModelScope.launch {
            repository.insertStudySubject(
                StudySubjectEntity(
                    name = name,
                    targetHoursTotal = targetHours,
                    completedHours = 0f
                ),
                chapters
            )
        }
    }

    fun scheduleSpacedRevisions(subjectName: String, topicTitle: String) {
        viewModelScope.launch {
            val today = DateUtils.todayString()
            listOf(1, 3, 7, 14, 30).forEach { interval ->
                repository.scheduleRevision(
                    StudyRevisionEntity(
                        subjectName = subjectName,
                        topicTitle = topicTitle,
                        intervalDay = interval,
                        scheduledDate = DateUtils.getDayOffset(today, interval),
                        isCompleted = false
                    )
                )
            }
        }
    }

    fun completeRevision(revision: StudyRevisionEntity) {
        viewModelScope.launch { repository.completeRevision(revision) }
    }

    fun createWorkoutRoutine(name: String, description: String, estimatedMinutes: Int, exercises: List<String>) {
        viewModelScope.launch {
            val exEntities = exercises.mapIndexed { idx, exName ->
                ExerciseEntity(
                    routineId = 0L,
                    name = exName,
                    targetSets = 4,
                    targetReps = 10,
                    orderIndex = idx
                )
            }
            repository.insertWorkoutRoutine(
                WorkoutRoutineEntity(
                    name = name,
                    description = description,
                    estimatedMinutes = estimatedMinutes
                ),
                exEntities
            )
        }
    }

    fun logWorkoutSession(routineName: String, durationMinutes: Int, totalSets: Int, totalReps: Int, totalVolumeKg: Float, notes: String) {
        viewModelScope.launch {
            repository.logWorkoutSession(
                WorkoutSessionEntity(
                    routineName = routineName,
                    durationMinutes = durationMinutes,
                    totalSets = totalSets,
                    totalReps = totalReps,
                    totalVolumeKg = totalVolumeKg,
                    date = DateUtils.todayString(),
                    notes = notes
                )
            )
        }
    }

    fun logFocusSession(taskTitle: String, category: String, mode: String, plannedMinutes: Int, actualMinutes: Int, completedSuccessfully: Boolean) {
        viewModelScope.launch {
            repository.logFocusSession(
                FocusSessionEntity(
                    taskTitle = taskTitle,
                    category = category,
                    mode = mode,
                    plannedMinutes = plannedMinutes,
                    actualMinutes = actualMinutes,
                    completedSuccessfully = completedSuccessfully,
                    date = DateUtils.todayString()
                )
            )
        }
    }

    fun saveDailyReview(whatWentWell: String, whatMissed: String, whyMissed: String, whatToChangeTomorrow: String, tomorrowPriority: String, notes: String) {
        viewModelScope.launch {
            val today = DateUtils.todayString()
            val score = todayUiState.value.todayScore.totalScore
            repository.saveDailyReview(
                DailyReviewEntity(
                    date = today,
                    score = score,
                    whatWentWell = whatWentWell,
                    whatMissed = whatMissed,
                    whyMissed = whyMissed,
                    whatToChangeTomorrow = whatToChangeTomorrow,
                    tomorrowPriority = tomorrowPriority,
                    notes = notes
                )
            )
        }
    }

    fun saveCountdown(title: String, targetDate: String, category: String, notes: String) {
        viewModelScope.launch {
            repository.insertCountdown(
                CountdownEntity(
                    title = title,
                    targetDate = targetDate,
                    category = category,
                    notes = notes
                )
            )
        }
    }

    fun deleteCountdown(countdown: CountdownEntity) {
        viewModelScope.launch { repository.deleteCountdown(countdown) }
    }

    fun saveOnboardingProfile(
        name: String,
        age: Int?,
        wakeUpTime: String,
        sleepTime: String,
        studyHours: Int,
        workoutMinutes: Int,
        workHours: Int,
        arcName: String,
        mainObjective: String,
        startDate: String,
        endDate: String,
        primaryGoalTitle: String,
        primaryGoalCategory: String
    ) {
        viewModelScope.launch {
            repository.saveUserProfile(
                UserProfileEntity(
                    name = name.ifBlank { "Arc Commander" },
                    age = age,
                    wakeUpTime = wakeUpTime,
                    sleepTime = sleepTime,
                    dailyStudyTargetMinutes = studyHours * 60,
                    dailyWorkoutTargetMinutes = workoutMinutes,
                    dailyWorkTargetMinutes = workHours * 60,
                    isOnboarded = true
                )
            )

            repository.saveWinterArc(
                WinterArcEntity(
                    arcName = arcName.ifBlank { "WINTER ARC" },
                    mainObjective = mainObjective.ifBlank { "Relentless discipline and physical/mental mastery." },
                    startDate = startDate.ifBlank { DateUtils.todayString() },
                    endDate = endDate.ifBlank { DateUtils.getDayOffset(DateUtils.todayString(), 90) },
                    totalDays = 90,
                    isActive = true
                )
            )

            if (primaryGoalTitle.isNotBlank()) {
                repository.insertGoal(
                    GoalEntity(
                        title = primaryGoalTitle,
                        category = primaryGoalCategory,
                        priority = TaskPriority.CRITICAL,
                        deadline = endDate.ifBlank { DateUtils.getDayOffset(DateUtils.todayString(), 90) },
                        progressPercent = 0
                    )
                )
            }
        }
    }

    fun clearAllData() {
        viewModelScope.launch {
            repository.clearAllData()
        }
    }
}
