package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val WinterArcDarkColorScheme = darkColorScheme(
    primary = IcyBluePrimary,
    onPrimary = ObsidianBlack,
    primaryContainer = SurfaceElevated,
    onPrimaryContainer = IcyBlueLight,
    secondary = CyanAccent,
    onSecondary = ObsidianBlack,
    secondaryContainer = SurfaceDark,
    onSecondaryContainer = IcyBluePrimary,
    tertiary = PurpleAccent,
    onTertiary = ObsidianBlack,
    tertiaryContainer = SurfaceElevated,
    onTertiaryContainer = FrostWhite,
    background = ObsidianBlack,
    onBackground = FrostWhite,
    surface = CharcoalDark,
    onSurface = FrostWhite,
    surfaceVariant = SurfaceDark,
    onSurfaceVariant = TextMuted,
    surfaceTint = IcyBluePrimary,
    outline = SurfaceBorder,
    outlineVariant = SurfaceBorderSubtle,
    error = CriticalRed,
    onError = FrostWhite,
    errorContainer = CriticalRedBg,
    onErrorContainer = FrostWhite
)

private val WinterArcLightColorScheme = lightColorScheme(
    primary = IcyBlueDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0F2FE),
    onPrimaryContainer = Color(0xFF0369A1),
    secondary = Color(0xFF0891B2),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFCFFAFE),
    onSecondaryContainer = Color(0xFF155E75),
    tertiary = Color(0xFF7E22CE),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFF3E8FF),
    onTertiaryContainer = Color(0xFF581C87),
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF475569),
    outline = Color(0xFFCBD5E1),
    outlineVariant = Color(0xFFE2E8F0),
    error = Color(0xFFDC2626),
    onError = Color.White,
    errorContainer = Color(0xFFFEE2E2),
    onErrorContainer = Color(0xFF991B1B)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // Dark theme is the visual identity of Winter Arc
    val colorScheme = if (darkTheme) WinterArcDarkColorScheme else WinterArcDarkColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
