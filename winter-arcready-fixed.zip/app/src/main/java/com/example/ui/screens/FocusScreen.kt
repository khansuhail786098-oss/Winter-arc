package com.example.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.DateUtils
import com.example.ui.MainViewModel
import com.example.ui.theme.CriticalRed
import com.example.ui.theme.FrostWhite
import com.example.ui.theme.IcyBlueDark
import com.example.ui.theme.IcyBlueLight
import com.example.ui.theme.IcyBluePrimary
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SurfaceBorder
import com.example.ui.theme.SurfaceBorderSubtle
import com.example.ui.theme.SurfaceDark
import com.example.ui.theme.SurfaceElevated
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WarningAmber
import kotlinx.coroutines.delay

@Composable
fun FocusScreen(
    viewModel: MainViewModel,
    taskId: Long? = null,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val allTasks by viewModel.allTasks.collectAsState()
    val boundTask = remember(taskId, allTasks) {
        if (taskId != null) allTasks.find { it.id == taskId } else null
    }

    var selectedModeMinutes by remember { mutableIntStateOf(boundTask?.durationMinutes ?: 50) }
    var secondsLeft by remember { mutableIntStateOf((boundTask?.durationMinutes ?: 50) * 60) }
    var isRunning by remember { mutableStateOf(false) }

    val totalDurationSeconds = maxOf(1, selectedModeMinutes * 60)
    val progress = (secondsLeft.toFloat() / totalDurationSeconds.toFloat())
    val animatedProgress by animateFloatAsState(targetValue = progress, label = "focus_progress")

    val disciplineQuotes = remember {
        listOf(
            "Do what is required, especially when you feel least like doing it.",
            "Winter Arc is not about motivation. It is about relentless execution.",
            "One undivided hour of deep focus beats eight hours of fractured multitasking.",
            "Suffering the pain of discipline is infinitely lighter than the pain of regret.",
            "Silence all distractions. You are building undeniable mastery."
        )
    }
    var currentQuoteIndex by remember { mutableIntStateOf(0) }

    LaunchedEffect(isRunning, secondsLeft) {
        if (isRunning && secondsLeft > 0) {
            delay(1000L)
            secondsLeft -= 1
            if (secondsLeft % 300 == 0) {
                currentQuoteIndex = (currentQuoteIndex + 1) % disciplineQuotes.size
            }
        } else if (secondsLeft == 0 && isRunning) {
            isRunning = false
            viewModel.logFocusSession(
                taskTitle = boundTask?.title ?: "Deep Focus Block",
                category = boundTask?.category?.name ?: "FOCUS",
                mode = "${selectedModeMinutes}m",
                plannedMinutes = selectedModeMinutes,
                actualMinutes = selectedModeMinutes,
                completedSuccessfully = true
            )
            if (boundTask != null) {
                viewModel.completeTask(boundTask.id)
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ObsidianBlack)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onNavigateBack) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = FrostWhite)
                }
                Surface(
                    color = IcyBluePrimary.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, IcyBluePrimary.copy(alpha = 0.4f))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = IcyBluePrimary, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "DISTRACTION BLOCK ACTIVE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Black,
                                color = IcyBlueLight
                            )
                        )
                    }
                }
                Spacer(modifier = Modifier.width(48.dp)) // balance icon
            }

            // Focus Target Title
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = boundTask?.title ?: "DEEP WORK FOCUS",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Black,
                        color = FrostWhite
                    ),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                if (boundTask?.description?.isNotBlank() == true) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = boundTask.description,
                        style = MaterialTheme.typography.bodySmall.copy(color = TextMuted),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }

            // Big Circular Countdown Meter
            Box(
                modifier = Modifier.size(260.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.size(240.dp)) {
                    // Background track
                    drawCircle(
                        color = SurfaceDark,
                        style = Stroke(width = 10.dp.toPx())
                    )
                    // Progress arc
                    drawArc(
                        brush = Brush.sweepGradient(
                            listOf(IcyBlueDark, IcyBluePrimary, IcyBlueLight)
                        ),
                        startAngle = -90f,
                        sweepAngle = 360f * animatedProgress,
                        useCenter = false,
                        style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    val minutes = secondsLeft / 60
                    val seconds = secondsLeft % 60
                    Text(
                        text = String.format("%02d:%02d", minutes, seconds),
                        style = MaterialTheme.typography.displayLarge.copy(
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp,
                            color = FrostWhite
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isRunning) "SESSION IN PROGRESS" else "PAUSED",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isRunning) IcyBluePrimary else TextDim,
                            letterSpacing = 1.sp
                        )
                    )
                }
            }

            // Mode Selector Pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                listOf(
                    Pair("Pomodoro", 25),
                    Pair("Deep Work", 50),
                    Pair("Extended Arc", 90)
                ).forEach { (label, mins) ->
                    val isSel = selectedModeMinutes == mins
                    Surface(
                        color = if (isSel) IcyBluePrimary else SurfaceElevated,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .padding(horizontal = 4.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                selectedModeMinutes = mins
                                secondsLeft = mins * 60
                                isRunning = false
                            }
                    ) {
                        Text(
                            text = "$label (${mins}m)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (isSel) ObsidianBlack else FrostWhite
                            ),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                        )
                    }
                }
            }

            // Motivational Cold Discipline Quote
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, SurfaceBorderSubtle),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "“${disciplineQuotes[currentQuoteIndex]}”",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = TextMuted,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    ),
                    modifier = Modifier.padding(14.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }

            // Controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Reset Button
                Surface(
                    color = SurfaceElevated,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            isRunning = false
                            secondsLeft = selectedModeMinutes * 60
                        }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = "Reset", tint = FrostWhite)
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                // Play / Pause Button
                Surface(
                    color = if (isRunning) WarningAmber else IcyBluePrimary,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .height(56.dp)
                        .width(160.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { isRunning = !isRunning }
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = ObsidianBlack
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isRunning) "PAUSE" else "START FOCUS",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Black,
                                color = ObsidianBlack
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                // Complete Button
                Surface(
                    color = SuccessGreen,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            isRunning = false
                            val actualMins = (totalDurationSeconds - secondsLeft) / 60
                            viewModel.logFocusSession(
                                taskTitle = boundTask?.title ?: "Deep Work Focus",
                                category = boundTask?.category?.name ?: "FOCUS",
                                mode = "${selectedModeMinutes}m",
                                plannedMinutes = selectedModeMinutes,
                                actualMinutes = maxOf(1, actualMins),
                                completedSuccessfully = true
                            )
                            if (boundTask != null) {
                                viewModel.completeTask(boundTask.id)
                            }
                            onNavigateBack()
                        }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = "Complete", tint = ObsidianBlack)
                    }
                }
            }
        }
    }
}
