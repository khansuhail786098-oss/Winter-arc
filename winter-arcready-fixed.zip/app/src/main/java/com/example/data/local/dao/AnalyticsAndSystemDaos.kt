package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.CountdownEntity
import com.example.data.local.entity.DailyReviewEntity
import com.example.data.local.entity.DailyScoreEntity
import com.example.data.local.entity.FocusSessionEntity
import com.example.data.local.entity.UserProfileEntity
import com.example.data.local.entity.WinterArcEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface FocusDao {
    @Query("SELECT * FROM focus_sessions ORDER BY timestamp DESC")
    fun getAllFocusSessions(): Flow<List<FocusSessionEntity>>

    @Query("SELECT * FROM focus_sessions WHERE date = :date")
    fun getFocusSessionsForDate(date: String): Flow<List<FocusSessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFocusSession(session: FocusSessionEntity): Long

    @Query("DELETE FROM focus_sessions")
    suspend fun clearAllFocusSessions()
}

@Dao
interface DailyScoreDao {
    @Query("SELECT * FROM daily_scores ORDER BY date DESC")
    fun getAllDailyScores(): Flow<List<DailyScoreEntity>>

    @Query("SELECT * FROM daily_scores WHERE date = :date LIMIT 1")
    fun getDailyScoreForDate(date: String): Flow<DailyScoreEntity?>

    @Query("SELECT * FROM daily_scores WHERE date = :date LIMIT 1")
    suspend fun getDailyScoreDirect(date: String): DailyScoreEntity?

    @Query("SELECT * FROM daily_scores ORDER BY date DESC LIMIT :limit")
    fun getRecentScores(limit: Int): Flow<List<DailyScoreEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateScore(score: DailyScoreEntity)

    @Query("DELETE FROM daily_scores")
    suspend fun clearAllScores()
}

@Dao
interface DailyReviewDao {
    @Query("SELECT * FROM daily_reviews ORDER BY date DESC")
    fun getAllDailyReviews(): Flow<List<DailyReviewEntity>>

    @Query("SELECT * FROM daily_reviews WHERE date = :date LIMIT 1")
    fun getReviewForDate(date: String): Flow<DailyReviewEntity?>

    @Query("SELECT * FROM daily_reviews WHERE date = :date LIMIT 1")
    suspend fun getReviewDirect(date: String): DailyReviewEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateReview(review: DailyReviewEntity)

    @Query("DELETE FROM daily_reviews")
    suspend fun clearAllReviews()
}

@Dao
interface CountdownDao {
    @Query("SELECT * FROM countdowns ORDER BY targetDate ASC")
    fun getAllCountdowns(): Flow<List<CountdownEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCountdown(countdown: CountdownEntity): Long

    @Delete
    suspend fun deleteCountdown(countdown: CountdownEntity)

    @Query("DELETE FROM countdowns")
    suspend fun clearAllCountdowns()
}

@Dao
interface UserDao {
    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    fun getUserProfile(): Flow<UserProfileEntity?>

    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    suspend fun getUserProfileDirect(): UserProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateUser(user: UserProfileEntity)

    @Query("SELECT * FROM winter_arc WHERE id = 1 LIMIT 1")
    fun getWinterArc(): Flow<WinterArcEntity?>

    @Query("SELECT * FROM winter_arc WHERE id = 1 LIMIT 1")
    suspend fun getWinterArcDirect(): WinterArcEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateWinterArc(arc: WinterArcEntity)
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM app_settings WHERE id = 1 LIMIT 1")
    fun getSettings(): Flow<AppSettingsEntity?>

    @Query("SELECT * FROM app_settings WHERE id = 1 LIMIT 1")
    suspend fun getSettingsDirect(): AppSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateSettings(settings: AppSettingsEntity)
}
