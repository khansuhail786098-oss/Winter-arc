package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.data.local.dao.CountdownDao
import com.example.data.local.dao.DailyReviewDao
import com.example.data.local.dao.DailyScoreDao
import com.example.data.local.dao.FocusDao
import com.example.data.local.dao.GoalDao
import com.example.data.local.dao.HabitDao
import com.example.data.local.dao.ProjectDao
import com.example.data.local.dao.SettingsDao
import com.example.data.local.dao.StudyDao
import com.example.data.local.dao.TaskDao
import com.example.data.local.dao.UserDao
import com.example.data.local.dao.WorkoutDao
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.CountdownEntity
import com.example.data.local.entity.DailyReviewEntity
import com.example.data.local.entity.DailyScoreEntity
import com.example.data.local.entity.ExerciseEntity
import com.example.data.local.entity.FocusSessionEntity
import com.example.data.local.entity.GoalEntity
import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.HabitLogEntity
import com.example.data.local.entity.MilestoneEntity
import com.example.data.local.entity.ProjectEntity
import com.example.data.local.entity.StudyChapterEntity
import com.example.data.local.entity.StudyRevisionEntity
import com.example.data.local.entity.StudySessionEntity
import com.example.data.local.entity.StudySubjectEntity
import com.example.data.local.entity.StudyTopicEntity
import com.example.data.local.entity.TaskEntity
import com.example.data.local.entity.UserProfileEntity
import com.example.data.local.entity.WinterArcEntity
import com.example.data.local.entity.WorkoutRoutineEntity
import com.example.data.local.entity.WorkoutSessionEntity

@Database(
    entities = [
        UserProfileEntity::class,
        WinterArcEntity::class,
        AppSettingsEntity::class,
        TaskEntity::class,
        HabitEntity::class,
        HabitLogEntity::class,
        GoalEntity::class,
        MilestoneEntity::class,
        ProjectEntity::class,
        StudySubjectEntity::class,
        StudyChapterEntity::class,
        StudyTopicEntity::class,
        StudySessionEntity::class,
        StudyRevisionEntity::class,
        WorkoutRoutineEntity::class,
        ExerciseEntity::class,
        WorkoutSessionEntity::class,
        FocusSessionEntity::class,
        DailyScoreEntity::class,
        DailyReviewEntity::class,
        CountdownEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class WinterArcDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun habitDao(): HabitDao
    abstract fun goalDao(): GoalDao
    abstract fun projectDao(): ProjectDao
    abstract fun studyDao(): StudyDao
    abstract fun workoutDao(): WorkoutDao
    abstract fun focusDao(): FocusDao
    abstract fun dailyScoreDao(): DailyScoreDao
    abstract fun dailyReviewDao(): DailyReviewDao
    abstract fun userDao(): UserDao
    abstract fun settingsDao(): SettingsDao
    abstract fun countdownDao(): CountdownDao

    companion object {
        @Volatile
        private var INSTANCE: WinterArcDatabase? = null

        fun getDatabase(context: Context): WinterArcDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    WinterArcDatabase::class.java,
                    "winter_arc_os.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
