package com.example.data.repository

import android.content.Context
import com.example.alarm.AlarmScheduler
import com.example.data.local.WinterArcDatabase
import com.example.data.local.entity.AppSettingsEntity
import com.example.data.local.entity.CountdownEntity
import com.example.data.local.entity.DailyReviewEntity
import com.example.data.local.entity.DailyScoreEntity
import com.example.data.local.entity.ExerciseEntity
import com.example.data.local.entity.FocusSessionEntity
import com.example.data.local.entity.GoalEntity
import com.example.data.local.entity.HabitEntity
import com.example.data.local.entity.HabitLogEntity
import com.example.data.local.entity.MilestoneEntity
import com.example.data.local.entity.ProjectEntity
import com.example.data.local.entity.StudyChapterEntity
import com.example.data.local.entity.StudyRevisionEntity
import com.example.data.local.entity.StudySessionEntity
import com.example.data.local.entity.StudySubjectEntity
import com.example.data.local.entity.StudyTopicEntity
import com.example.data.local.entity.TaskCategory
import com.example.data.local.entity.TaskEntity
import com.example.data.local.entity.TaskPriority
import com.example.data.local.entity.TaskStatus
import com.example.data.local.entity.UserProfileEntity
import com.example.data.local.entity.WinterArcEntity
import com.example.data.local.entity.WorkoutRoutineEntity
import com.example.data.local.entity.WorkoutSessionEntity
import com.example.domain.DailyScoreCalculator
import com.example.domain.DateUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import org.json.JSONArray
import org.json.JSONObject

class WinterArcRepository(
    private val context: Context,
    private val database: WinterArcDatabase = WinterArcDatabase.getDatabase(context)
) {
    val userProfile: Flow<UserProfileEntity?> = database.userDao().getUserProfile()
    val winterArc: Flow<WinterArcEntity?> = database.userDao().getWinterArc()
    val appSettings: Flow<AppSettingsEntity?> = database.settingsDao().getSettings()

    val allTasks: Flow<List<TaskEntity>> = database.taskDao().getAllTasks()
    val allHabits: Flow<List<HabitEntity>> = database.habitDao().getAllHabits()
    val allGoals: Flow<List<GoalEntity>> = database.goalDao().getAllGoals()
    val allProjects: Flow<List<ProjectEntity>> = database.projectDao().getAllProjects()
    val allSubjects: Flow<List<StudySubjectEntity>> = database.studyDao().getAllSubjects()
    val allStudySessions: Flow<List<StudySessionEntity>> = database.studyDao().getAllStudySessions()
    val pendingRevisions: Flow<List<StudyRevisionEntity>> = database.studyDao().getPendingRevisions()
    val allWorkoutRoutines: Flow<List<WorkoutRoutineEntity>> = database.workoutDao().getAllRoutines()
    val allWorkoutSessions: Flow<List<WorkoutSessionEntity>> = database.workoutDao().getAllWorkoutSessions()
    val allFocusSessions: Flow<List<FocusSessionEntity>> = database.focusDao().getAllFocusSessions()
    val allDailyScores: Flow<List<DailyScoreEntity>> = database.dailyScoreDao().getAllDailyScores()
    val allDailyReviews: Flow<List<DailyReviewEntity>> = database.dailyReviewDao().getAllDailyReviews()
    val allCountdowns: Flow<List<CountdownEntity>> = database.countdownDao().getAllCountdowns()

    fun getTasksForDate(date: String): Flow<List<TaskEntity>> = database.taskDao().getTasksForDate(date)
    fun getHabitLogsForDate(date: String): Flow<List<HabitLogEntity>> = database.habitDao().getLogsForDate(date)
    fun getDailyScoreForDate(date: String): Flow<DailyScoreEntity?> = database.dailyScoreDao().getDailyScoreForDate(date)
    fun getDailyReviewForDate(date: String): Flow<DailyReviewEntity?> = database.dailyReviewDao().getReviewForDate(date)
    fun getChaptersForSubject(subjectId: Long): Flow<List<StudyChapterEntity>> = database.studyDao().getChaptersForSubject(subjectId)
    fun getTopicsForChapter(chapterId: Long): Flow<List<StudyTopicEntity>> = database.studyDao().getTopicsForChapter(chapterId)
    fun getExercisesForRoutine(routineId: Long): Flow<List<ExerciseEntity>> = database.workoutDao().getExercisesForRoutine(routineId)
    fun getMilestonesForGoal(goalId: Long): Flow<List<MilestoneEntity>> = database.goalDao().getMilestonesForGoal(goalId)

    suspend fun saveUserProfile(profile: UserProfileEntity) {
        database.userDao().insertOrUpdateUser(profile)
    }

    suspend fun saveWinterArc(arc: WinterArcEntity) {
        database.userDao().insertOrUpdateWinterArc(arc)
    }

    suspend fun saveAppSettings(settings: AppSettingsEntity) {
        database.settingsDao().insertOrUpdateSettings(settings)
    }

    suspend fun insertTask(task: TaskEntity): Long {
        val id = database.taskDao().insertTask(task)
        val created = task.copy(id = id)
        if (created.isAlarmEnabled) {
            AlarmScheduler.scheduleTaskAlarm(context, created)
        }
        recalculateScoreForDate(task.plannedDate)
        return id
    }

    suspend fun updateTask(task: TaskEntity) {
        database.taskDao().updateTask(task)
        if (task.isAlarmEnabled) {
            AlarmScheduler.scheduleTaskAlarm(context, task)
        } else {
            AlarmScheduler.cancelTaskAlarm(context, task.id)
        }
        recalculateScoreForDate(task.plannedDate)
    }

    suspend fun updateTaskStatus(taskId: Long, status: TaskStatus) {
        val completedAt = if (status == TaskStatus.COMPLETED) System.currentTimeMillis() else null
        database.taskDao().updateTaskStatus(taskId, status, completedAt)
        val task = database.taskDao().getTaskByIdDirect(taskId)
        task?.let {
            if (status == TaskStatus.COMPLETED) {
                AlarmScheduler.cancelTaskAlarm(context, taskId)
            }
            recalculateScoreForDate(it.plannedDate)
        }
    }

    suspend fun deleteTask(task: TaskEntity) {
        AlarmScheduler.cancelTaskAlarm(context, task.id)
        database.taskDao().deleteTask(task)
        recalculateScoreForDate(task.plannedDate)
    }

    suspend fun rescheduleTask(taskId: Long, newDate: String) {
        database.taskDao().rescheduleTask(taskId, newDate)
        val task = database.taskDao().getTaskByIdDirect(taskId)
        task?.let {
            AlarmScheduler.scheduleTaskAlarm(context, it)
            recalculateScoreForDate(newDate)
        }
    }

    suspend fun toggleHabitCompletion(habitId: Long, date: String) {
        val existing = database.habitDao().getLogForHabitAndDate(habitId, date)
        if (existing != null) {
            database.habitDao().deleteHabitLog(habitId, date)
        } else {
            database.habitDao().insertHabitLog(
                HabitLogEntity(
                    habitId = habitId,
                    date = date,
                    isCompleted = true,
                    completedAt = System.currentTimeMillis()
                )
            )
        }
        // Update habit streak
        val habit = database.habitDao().getHabitById(habitId)
        if (habit != null) {
            val logs = database.habitDao().getLogsForHabit(habitId).firstOrNull() ?: emptyList()
            val newStreak = logs.size
            database.habitDao().updateHabit(
                habit.copy(
                    currentStreak = newStreak,
                    bestStreak = maxOf(habit.bestStreak, newStreak)
                )
            )
        }
        recalculateScoreForDate(date)
    }

    suspend fun insertHabit(habit: HabitEntity): Long = database.habitDao().insertHabit(habit)
    suspend fun updateHabit(habit: HabitEntity) = database.habitDao().updateHabit(habit)
    suspend fun deleteHabit(habit: HabitEntity) = database.habitDao().deleteHabit(habit)

    suspend fun insertGoal(goal: GoalEntity, milestones: List<MilestoneEntity> = emptyList()): Long {
        val goalId = database.goalDao().insertGoal(goal)
        milestones.forEach {
            database.goalDao().insertMilestone(it.copy(goalId = goalId))
        }
        return goalId
    }
    suspend fun updateGoal(goal: GoalEntity) = database.goalDao().updateGoal(goal)
    suspend fun deleteGoal(goal: GoalEntity) = database.goalDao().deleteGoal(goal)

    suspend fun insertProject(project: ProjectEntity): Long = database.projectDao().insertProject(project)
    suspend fun updateProject(project: ProjectEntity) = database.projectDao().updateProject(project)
    suspend fun deleteProject(project: ProjectEntity) = database.projectDao().deleteProject(project)

    suspend fun insertSubject(subject: StudySubjectEntity): Long = database.studyDao().insertSubject(subject)
    suspend fun insertStudySubject(subject: StudySubjectEntity, chapters: List<String> = emptyList()): Long {
        val subjectId = database.studyDao().insertSubject(subject)
        chapters.forEachIndexed { index, chapterTitle ->
            database.studyDao().insertChapter(
                StudyChapterEntity(
                    subjectId = subjectId,
                    title = chapterTitle,
                    orderIndex = index
                )
            )
        }
        return subjectId
    }
    suspend fun insertChapter(chapter: StudyChapterEntity): Long = database.studyDao().insertChapter(chapter)
    suspend fun insertTopic(topic: StudyTopicEntity): Long = database.studyDao().insertTopic(topic)
    suspend fun logStudySession(session: StudySessionEntity): Long {
        val id = database.studyDao().insertSession(session)
        recalculateScoreForDate(session.date)
        return id
    }
    suspend fun scheduleRevision(revision: StudyRevisionEntity) = database.studyDao().insertRevision(revision)
    suspend fun completeRevision(revision: StudyRevisionEntity) {
        database.studyDao().updateRevision(revision.copy(isCompleted = true, completedAt = System.currentTimeMillis()))
    }

    suspend fun insertWorkoutRoutine(routine: WorkoutRoutineEntity, exercises: List<ExerciseEntity>): Long {
        val routineId = database.workoutDao().insertRoutine(routine)
        exercises.forEach {
            database.workoutDao().insertExercise(it.copy(routineId = routineId))
        }
        return routineId
    }
    suspend fun logWorkoutSession(session: WorkoutSessionEntity): Long {
        val id = database.workoutDao().insertSession(session)
        recalculateScoreForDate(session.date)
        return id
    }

    suspend fun logFocusSession(session: FocusSessionEntity): Long {
        val id = database.focusDao().insertFocusSession(session)
        recalculateScoreForDate(session.date)
        return id
    }

    suspend fun saveDailyReview(review: DailyReviewEntity) {
        database.dailyReviewDao().insertOrUpdateReview(review)
    }

    suspend fun insertCountdown(countdown: CountdownEntity): Long = database.countdownDao().insertCountdown(countdown)
    suspend fun deleteCountdown(countdown: CountdownEntity) = database.countdownDao().deleteCountdown(countdown)

    suspend fun recalculateScoreForDate(date: String) {
        val profile = database.userDao().getUserProfileDirect() ?: UserProfileEntity()
        val tasks = database.taskDao().getTasksForDate(date).firstOrNull() ?: emptyList()
        val habits = database.habitDao().getAllHabits().firstOrNull() ?: emptyList()
        val habitLogs = database.habitDao().getLogsForDate(date).firstOrNull() ?: emptyList()
        val studySessions = database.studyDao().getStudySessionsForDate(date).firstOrNull() ?: emptyList()
        val workoutSessions = database.workoutDao().getWorkoutSessionsForDate(date).firstOrNull() ?: emptyList()

        val studyMinutes = studySessions.sumOf { it.durationMinutes } +
                tasks.filter { it.category == TaskCategory.STUDY && it.status == TaskStatus.COMPLETED }.sumOf { it.durationMinutes }
        val workoutMinutes = workoutSessions.sumOf { it.durationMinutes } +
                tasks.filter { it.category == TaskCategory.WORKOUT && it.status == TaskStatus.COMPLETED }.sumOf { it.durationMinutes }
        val workMinutes = tasks.filter { it.category == TaskCategory.WORK && it.status == TaskStatus.COMPLETED }.sumOf { it.durationMinutes }

        val scoreEntity = DailyScoreCalculator.calculateScore(
            date = date,
            profile = profile,
            tasks = tasks,
            habits = habits,
            habitLogs = habitLogs,
            studyMinutesTotal = studyMinutes,
            workoutMinutesTotal = workoutMinutes,
            workMinutesTotal = workMinutes
        )
        database.dailyScoreDao().insertOrUpdateScore(scoreEntity)
    }

    suspend fun loadSampleDemoData() {
        val today = DateUtils.todayString()
        val tomorrow = DateUtils.getDayOffset(today, 1)

        // 1. Profile & Arc
        database.userDao().insertOrUpdateUser(
            UserProfileEntity(
                name = "Arc Commander",
                age = 22,
                wakeUpTime = "05:30",
                sleepTime = "22:30",
                dailyStudyTargetMinutes = 360,
                dailyWorkoutTargetMinutes = 60,
                dailyWorkTargetMinutes = 180,
                isOnboarded = true
            )
        )
        database.userDao().insertOrUpdateWinterArc(
            WinterArcEntity(
                arcName = "WINTER ARC 2026",
                mainObjective = "Become undeniable. Deep mastery in Physics, Physical Strength, and Software Architecture.",
                startDate = DateUtils.getDayOffset(today, -11),
                endDate = DateUtils.getDayOffset(today, 78),
                totalDays = 90,
                isActive = true
            )
        )

        // 2. Tasks for Today
        val sampleTasks = listOf(
            TaskEntity(
                title = "Physics — Electrostatics & Gauss's Law",
                description = "Solve 25 advanced derivation numericals & complete chapter revision notes.",
                category = TaskCategory.STUDY,
                priority = TaskPriority.CRITICAL,
                status = TaskStatus.PLANNED,
                plannedDate = today,
                startTime = "08:00",
                endTime = "10:30",
                durationMinutes = 150,
                isAlarmEnabled = true,
                isHighAlertEnabled = true
            ),
            TaskEntity(
                title = "Push Day Workout — Chest, Delts & Triceps",
                description = "Heavy Barbell Bench Press (5x5), Overhead Press (4x8), Incline DB Press, Dips.",
                category = TaskCategory.WORKOUT,
                priority = TaskPriority.HIGH,
                status = TaskStatus.PLANNED,
                plannedDate = today,
                startTime = "11:00",
                endTime = "12:15",
                durationMinutes = 75,
                isAlarmEnabled = true
            ),
            TaskEntity(
                title = "Engineering — Android OS Offline Architecture",
                description = "Complete Room schema migration, state hoisting and navigation backstack unit tests.",
                category = TaskCategory.WORK,
                priority = TaskPriority.HIGH,
                status = TaskStatus.COMPLETED,
                plannedDate = today,
                startTime = "14:00",
                endTime = "16:30",
                durationMinutes = 150,
                completedAt = System.currentTimeMillis() - 100000
            ),
            TaskEntity(
                title = "Chemistry — Chemical Bonding & Molecular Structure",
                description = "VSEPR theory, Hybridization geometry and MOT energy level diagrams.",
                category = TaskCategory.STUDY,
                priority = TaskPriority.HIGH,
                status = TaskStatus.COMPLETED,
                plannedDate = today,
                startTime = "17:00",
                endTime = "18:30",
                durationMinutes = 90,
                completedAt = System.currentTimeMillis() - 50000
            ),
            TaskEntity(
                title = "Mathematics — Linear Algebra & Eigenvectors",
                description = "Matrix transformations and characteristic polynomial proofs.",
                category = TaskCategory.STUDY,
                priority = TaskPriority.NORMAL,
                status = TaskStatus.PLANNED,
                plannedDate = today,
                startTime = "19:30",
                endTime = "21:00",
                durationMinutes = 90,
                isAlarmEnabled = true
            ),
            TaskEntity(
                title = "Nightly Review & Tomorrow Strategy",
                description = "Log day metrics, analyze commitment gaps, prepare tomorrow's plan.",
                category = TaskCategory.PERSONAL,
                priority = TaskPriority.NORMAL,
                status = TaskStatus.PLANNED,
                plannedDate = today,
                startTime = "21:45",
                endTime = "22:15",
                durationMinutes = 30
            )
        )
        sampleTasks.forEach { database.taskDao().insertTask(it) }

        // 3. Habits
        val habits = listOf(
            HabitEntity(name = "Wake up at 05:30 AM", iconName = "alarm", currentStreak = 12, bestStreak = 24),
            HabitEntity(name = "Drink 3.5L Water", iconName = "water_drop", currentStreak = 12, bestStreak = 30),
            HabitEntity(name = "No Aimless Scrolling / Zero Junk Feed", iconName = "block", currentStreak = 18, bestStreak = 18),
            HabitEntity(name = "Read 20 pages (Philosophy / Tech)", iconName = "menu_book", currentStreak = 8, bestStreak = 15),
            HabitEntity(name = "100 Pushups & Mobility Work", iconName = "fitness_center", currentStreak = 14, bestStreak = 21),
            HabitEntity(name = "Sleep by 10:30 PM", iconName = "bedtime", currentStreak = 11, bestStreak = 19)
        )
        habits.forEach { habit ->
            val id = database.habitDao().insertHabit(habit)
            // Log today's check for first 4 habits
            if (habit.name.contains("Wake") || habit.name.contains("Water") || habit.name.contains("Scrolling") || habit.name.contains("Pushups")) {
                database.habitDao().insertHabitLog(
                    HabitLogEntity(habitId = id, date = today, isCompleted = true)
                )
            }
        }

        // 4. Goals
        val goal1 = GoalEntity(
            title = "Rank Top 1% in National Competitive Exam",
            description = "Master complete syllabus across Physics, Chemistry, and Advanced Mathematics.",
            category = "Academics",
            priority = TaskPriority.CRITICAL,
            deadline = DateUtils.getDayOffset(today, 64),
            progressPercent = 58
        )
        val g1Id = database.goalDao().insertGoal(goal1)
        database.goalDao().insertMilestone(MilestoneEntity(goalId = g1Id, title = "Physics Mechanics & Electrodynamics", progressPercent = 75, isCompleted = false))
        database.goalDao().insertMilestone(MilestoneEntity(goalId = g1Id, title = "Organic & Physical Chemistry", progressPercent = 60, isCompleted = false))
        database.goalDao().insertMilestone(MilestoneEntity(goalId = g1Id, title = "Calculus & Coordinate Geometry", progressPercent = 40, isCompleted = false))

        val goal2 = GoalEntity(
            title = "Physical Peak: 80kg at 10% Body Fat",
            description = "Consistent progressive overload, 160g daily protein, unbroken workout frequency.",
            category = "Fitness",
            priority = TaskPriority.HIGH,
            deadline = DateUtils.getDayOffset(today, 78),
            progressPercent = 45
        )
        database.goalDao().insertGoal(goal2)

        // 5. Projects
        val project1 = ProjectEntity(
            name = "Winter Arc Android OS",
            description = "Build a high-performance, local-first offline operating system for discipline and self-mastery.",
            deadline = DateUtils.getDayOffset(today, 30),
            priority = TaskPriority.CRITICAL,
            progressPercent = 70,
            totalTasks = 10,
            completedTasks = 7
        )
        database.projectDao().insertProject(project1)

        // 6. Study Subjects & Chapters
        val subPhysics = StudySubjectEntity(name = "Physics", colorHex = "#38BDF8", targetHoursTotal = 120, completedHours = 64f, iconName = "bolt")
        val physId = database.studyDao().insertSubject(subPhysics)
        val ch1 = database.studyDao().insertChapter(StudyChapterEntity(subjectId = physId, title = "Electrostatics & Capacitance", orderIndex = 1, isCompleted = false))
        database.studyDao().insertTopic(StudyTopicEntity(chapterId = ch1, title = "Coulomb's Law & Electric Fields", plannedMinutes = 90, actualMinutes = 90, isCompleted = true))
        database.studyDao().insertTopic(StudyTopicEntity(chapterId = ch1, title = "Gauss Law & Flux Proofs", plannedMinutes = 120, actualMinutes = 110, isCompleted = true))
        database.studyDao().insertTopic(StudyTopicEntity(chapterId = ch1, title = "Capacitance & Dielectric Polarization", plannedMinutes = 90, actualMinutes = 0, isCompleted = false))

        val subChem = StudySubjectEntity(name = "Chemistry", colorHex = "#10B981", targetHoursTotal = 100, completedHours = 48f, iconName = "science")
        val chemId = database.studyDao().insertSubject(subChem)
        val chChem = database.studyDao().insertChapter(StudyChapterEntity(subjectId = chemId, title = "Chemical Bonding & Thermodynamics", orderIndex = 1, isCompleted = false))
        database.studyDao().insertTopic(StudyTopicEntity(chapterId = chChem, title = "Hybridization & Molecular Orbitals", plannedMinutes = 90, actualMinutes = 90, isCompleted = true))

        val subMath = StudySubjectEntity(name = "Mathematics", colorHex = "#A855F7", targetHoursTotal = 140, completedHours = 72f, iconName = "functions")
        database.studyDao().insertSubject(subMath)

        // Study revisions
        database.studyDao().insertRevision(StudyRevisionEntity(subjectName = "Physics", topicTitle = "Coulomb's Law Numerical Mastery", intervalDay = 3, scheduledDate = today, isCompleted = false))
        database.studyDao().insertRevision(StudyRevisionEntity(subjectName = "Chemistry", topicTitle = "Periodic Properties & VSEPR", intervalDay = 7, scheduledDate = tomorrow, isCompleted = false))

        // 7. Workout Routines
        val pushRoutine = WorkoutRoutineEntity(name = "Push Day (Hypertrophy & Strength)", description = "Chest, Shoulders & Triceps Focus", estimatedMinutes = 70, dayOfWeek = "Monday, Thursday", totalSessionsCompleted = 14)
        val pushId = database.workoutDao().insertRoutine(pushRoutine)
        database.workoutDao().insertExercise(ExerciseEntity(routineId = pushId, name = "Barbell Flat Bench Press", targetSets = 5, targetReps = 5, targetWeightKg = 85f, restSeconds = 120, orderIndex = 1))
        database.workoutDao().insertExercise(ExerciseEntity(routineId = pushId, name = "Standing Overhead Barbell Press", targetSets = 4, targetReps = 8, targetWeightKg = 55f, restSeconds = 90, orderIndex = 2))
        database.workoutDao().insertExercise(ExerciseEntity(routineId = pushId, name = "Incline Dumbbell Press", targetSets = 4, targetReps = 10, targetWeightKg = 30f, restSeconds = 75, orderIndex = 3))
        database.workoutDao().insertExercise(ExerciseEntity(routineId = pushId, name = "Tricep Parallel Dips (Weighted)", targetSets = 3, targetReps = 12, targetWeightKg = 15f, restSeconds = 60, orderIndex = 4))

        val pullRoutine = WorkoutRoutineEntity(name = "Pull Day (Back, Rear Delts & Biceps)", description = "Lats, Traps & Forearms", estimatedMinutes = 65, dayOfWeek = "Tuesday, Friday", totalSessionsCompleted = 13)
        val pullId = database.workoutDao().insertRoutine(pullRoutine)
        database.workoutDao().insertExercise(ExerciseEntity(routineId = pullId, name = "Barbell Deadlift", targetSets = 5, targetReps = 5, targetWeightKg = 140f, restSeconds = 180, orderIndex = 1))
        database.workoutDao().insertExercise(ExerciseEntity(routineId = pullId, name = "Weighted Pull-Ups", targetSets = 4, targetReps = 8, targetWeightKg = 10f, restSeconds = 90, orderIndex = 2))

        // 8. Countdowns
        database.countdownDao().insertCountdown(CountdownEntity(title = "Major Academic Competitive Exam", targetDate = DateUtils.getDayOffset(today, 47), category = "EXAM"))
        database.countdownDao().insertCountdown(CountdownEntity(title = "Winter Arc Season Completion", targetDate = DateUtils.getDayOffset(today, 78), category = "ARC_END"))

        // 9. Past Scores for charts
        for (i in 7 downTo 1) {
            val pastDate = DateUtils.getDayOffset(today, -i)
            val score = when (i) {
                1 -> 84
                2 -> 76
                3 -> 92
                4 -> 88
                5 -> 70
                6 -> 85
                7 -> 80
                else -> 82
            }
            database.dailyScoreDao().insertOrUpdateScore(
                DailyScoreEntity(
                    date = pastDate,
                    totalScore = score,
                    studyMinutes = 320 - (i * 10),
                    studyTargetMinutes = 360,
                    workoutMinutes = 60,
                    workoutTargetMinutes = 60,
                    workMinutes = 150,
                    workTargetMinutes = 180,
                    habitsCompleted = 5,
                    habitsTotal = 6,
                    tasksCompleted = 5,
                    tasksTotal = 6,
                    tasksMissed = if (i == 5) 1 else 0
                )
            )
        }

        recalculateScoreForDate(today)
    }

    suspend fun clearAllData() {
        database.taskDao().clearAllTasks()
        database.habitDao().clearAllHabits()
        database.habitDao().clearAllHabitLogs()
        database.goalDao().clearAllGoals()
        database.goalDao().clearAllMilestones()
        database.projectDao().clearAllProjects()
        database.studyDao().clearAllStudy()
        database.workoutDao().clearAllWorkoutRoutines()
        database.workoutDao().clearAllExercises()
        database.workoutDao().clearAllWorkoutSessions()
        database.focusDao().clearAllFocusSessions()
        database.dailyScoreDao().clearAllScores()
        database.dailyReviewDao().clearAllReviews()
        database.countdownDao().clearAllCountdowns()
    }

    suspend fun exportDataAsJson(): String {
        val root = JSONObject()
        val user = database.userDao().getUserProfileDirect()
        val arc = database.userDao().getWinterArcDirect()
        val tasks = database.taskDao().getAllTasks().firstOrNull() ?: emptyList()
        val habits = database.habitDao().getAllHabits().firstOrNull() ?: emptyList()
        val goals = database.goalDao().getAllGoals().firstOrNull() ?: emptyList()
        val scores = database.dailyScoreDao().getAllDailyScores().firstOrNull() ?: emptyList()

        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())
        root.put("userName", user?.name ?: "Arc Commander")
        root.put("arcName", arc?.arcName ?: "Winter Arc")

        val tasksArray = JSONArray()
        tasks.forEach { t ->
            val obj = JSONObject().apply {
                put("title", t.title)
                put("category", t.category.name)
                put("priority", t.priority.name)
                put("status", t.status.name)
                put("date", t.plannedDate)
                put("startTime", t.startTime)
                put("durationMinutes", t.durationMinutes)
            }
            tasksArray.put(obj)
        }
        root.put("tasks", tasksArray)

        val habitsArray = JSONArray()
        habits.forEach { h ->
            val obj = JSONObject().apply {
                put("name", h.name)
                put("streak", h.currentStreak)
                put("bestStreak", h.bestStreak)
            }
            habitsArray.put(obj)
        }
        root.put("habits", habitsArray)

        val scoresArray = JSONArray()
        scores.forEach { s ->
            val obj = JSONObject().apply {
                put("date", s.date)
                put("score", s.totalScore)
            }
            scoresArray.put(obj)
        }
        root.put("dailyScores", scoresArray)

        return root.toString(2)
    }
}
