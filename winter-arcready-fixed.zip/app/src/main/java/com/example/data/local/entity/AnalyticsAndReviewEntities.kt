package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "focus_sessions")
data class FocusSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val taskTitle: String,
    val category: String = "STUDY",
    val mode: String = "POMODORO", // POMODORO, TIMER, STOPWATCH
    val plannedMinutes: Int,
    val actualMinutes: Int,
    val completedSuccessfully: Boolean = true,
    val date: String, // YYYY-MM-DD
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "daily_scores")
data class DailyScoreEntity(
    @PrimaryKey val date: String, // YYYY-MM-DD
    val totalScore: Int = 0, // 0 to 100
    val studyMinutes: Int = 0,
    val studyTargetMinutes: Int = 360,
    val workoutMinutes: Int = 0,
    val workoutTargetMinutes: Int = 60,
    val workMinutes: Int = 0,
    val workTargetMinutes: Int = 180,
    val habitsCompleted: Int = 0,
    val habitsTotal: Int = 0,
    val tasksCompleted: Int = 0,
    val tasksTotal: Int = 0,
    val tasksMissed: Int = 0,
    val sleepConsistencyScore: Int = 100,
    val calculatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "daily_reviews")
data class DailyReviewEntity(
    @PrimaryKey val date: String, // YYYY-MM-DD
    val score: Int = 0,
    val whatWentWell: String = "",
    val whatMissed: String = "",
    val whyMissed: String = "",
    val whatToChangeTomorrow: String = "",
    val tomorrowPriority: String = "",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "countdowns")
data class CountdownEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val targetDate: String, // YYYY-MM-DD
    val category: String = "EXAM", // EXAM, ARC_END, PROJECT, MILESTONE
    val notes: String = ""
)
