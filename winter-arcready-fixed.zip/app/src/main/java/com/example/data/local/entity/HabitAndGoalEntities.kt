package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val iconName: String = "bolt",
    val targetDaysPerWeek: Int = 7,
    val reminderTime: String = "08:00",
    val currentStreak: Int = 0,
    val bestStreak: Int = 0,
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "habit_logs")
data class HabitLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val habitId: Long,
    val date: String, // YYYY-MM-DD
    val isCompleted: Boolean = true,
    val completedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "goals")
data class GoalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val description: String = "",
    val category: String = "Discipline",
    val priority: TaskPriority = TaskPriority.HIGH,
    val deadline: String = "", // YYYY-MM-DD
    val progressPercent: Int = 0,
    val notes: String = "",
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "milestones")
data class MilestoneEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val goalId: Long,
    val title: String,
    val progressPercent: Int = 0,
    val isCompleted: Boolean = false,
    val deadline: String = ""
)

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val description: String = "",
    val deadline: String = "",
    val priority: TaskPriority = TaskPriority.HIGH,
    val status: String = "IN_PROGRESS", // NOT_STARTED, IN_PROGRESS, COMPLETED
    val progressPercent: Int = 0,
    val totalTasks: Int = 0,
    val completedTasks: Int = 0,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
