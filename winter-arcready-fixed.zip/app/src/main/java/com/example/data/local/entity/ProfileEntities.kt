package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val id: Int = 1,
    val name: String = "Arc Commander",
    val age: Int? = null,
    val wakeUpTime: String = "06:00",
    val sleepTime: String = "22:30",
    val dailyStudyTargetMinutes: Int = 360, // 6h
    val dailyWorkoutTargetMinutes: Int = 60, // 1h
    val dailyWorkTargetMinutes: Int = 180, // 3h
    val isOnboarded: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "winter_arc")
data class WinterArcEntity(
    @PrimaryKey val id: Int = 1,
    val arcName: String = "WINTER ARC 2026",
    val mainObjective: String = "Relentless discipline, physical mastery, deep focus & high performance.",
    val startDate: String = "", // YYYY-MM-DD
    val endDate: String = "",
    val startTimestamp: Long = 0L,
    val endTimestamp: Long = 0L,
    val totalDays: Int = 90,
    val isActive: Boolean = true
)

@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val isDarkMode: Boolean = true,
    val accentColor: String = "#38BDF8",
    val notificationsEnabled: Boolean = true,
    val highAlertEnabled: Boolean = true,
    val missedTaskAlertsEnabled: Boolean = true,
    val dailyBriefingEnabled: Boolean = true,
    val nightReviewEnabled: Boolean = true,
    val defaultTaskDurationMinutes: Int = 60,
    val defaultPomodoroMinutes: Int = 25,
    val defaultBreakMinutes: Int = 5,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true
)
