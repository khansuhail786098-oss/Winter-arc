package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.TaskCategory
import com.example.data.local.entity.TaskEntity
import com.example.data.local.entity.TaskStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks WHERE plannedDate = :date ORDER BY startTime ASC, id ASC")
    fun getTasksForDate(date: String): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE plannedDate = :date AND status = :status ORDER BY startTime ASC")
    fun getTasksForDateAndStatus(date: String, status: TaskStatus): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE plannedDate = :date AND status != 'COMPLETED' AND status != 'SKIPPED' ORDER BY startTime ASC")
    fun getUncompletedTasksForDate(date: String): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE plannedDate = :date AND status = 'MISSED' ORDER BY startTime ASC")
    fun getMissedTasksForDate(date: String): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE plannedDate < :currentDate AND status = 'PLANNED'")
    suspend fun getOverduePlannedTasks(currentDate: String): List<TaskEntity>

    @Query("SELECT * FROM tasks WHERE id = :id")
    fun getTaskById(id: Long): Flow<TaskEntity?>

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun getTaskByIdDirect(id: Long): TaskEntity?

    @Query("SELECT * FROM tasks WHERE isAlarmEnabled = 1 AND plannedDate >= :fromDate")
    suspend fun getScheduledAlarmTasks(fromDate: String): List<TaskEntity>

    @Query("SELECT * FROM tasks ORDER BY plannedDate DESC, startTime ASC")
    fun getAllTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE title LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%'")
    fun searchTasks(query: String): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE category = :category AND status = 'COMPLETED'")
    fun getCompletedTasksByCategory(category: TaskCategory): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE projectId = :projectId ORDER BY id ASC")
    fun getTasksForProject(projectId: Long): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE goalId = :goalId ORDER BY id ASC")
    fun getTasksForGoal(goalId: Long): Flow<List<TaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTasks(tasks: List<TaskEntity>)

    @Update
    suspend fun updateTask(task: TaskEntity)

    @Delete
    suspend fun deleteTask(task: TaskEntity)

    @Query("DELETE FROM tasks WHERE id = :id")
    suspend fun deleteTaskById(id: Long)

    @Query("UPDATE tasks SET status = :status, completedAt = :completedAt WHERE id = :id")
    suspend fun updateTaskStatus(id: Long, status: TaskStatus, completedAt: Long?)

    @Query("UPDATE tasks SET plannedDate = :newDate, status = 'RESCHEDULED', rescheduledCount = rescheduledCount + 1 WHERE id = :id")
    suspend fun rescheduleTask(id: Long, newDate: String)

    @Query("DELETE FROM tasks")
    suspend fun clearAllTasks()
}
