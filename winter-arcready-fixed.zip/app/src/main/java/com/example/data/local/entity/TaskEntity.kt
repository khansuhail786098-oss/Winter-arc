package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TaskPriority {
    NORMAL, HIGH, CRITICAL
}

enum class TaskStatus {
    PLANNED, ACTIVE, COMPLETED, MISSED, SKIPPED, RESCHEDULED
}

enum class TaskCategory {
    STUDY, WORKOUT, WORK, HABIT, PERSONAL, OTHER
}

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val title: String,
    val description: String = "",
    val category: TaskCategory = TaskCategory.STUDY,
    val priority: TaskPriority = TaskPriority.NORMAL,
    val status: TaskStatus = TaskStatus.PLANNED,
    val plannedDate: String, // YYYY-MM-DD
    val startTime: String = "", // HH:mm
    val endTime: String = "", // HH:mm
    val durationMinutes: Int = 60,
    val actualDurationMinutes: Int = 0,
    val isAlarmEnabled: Boolean = false,
    val isHighAlertEnabled: Boolean = false,
    val alarmStage: Int = 0, // 0 to 5
    val rescheduledCount: Int = 0,
    val goalId: Long? = null,
    val projectId: Long? = null,
    val notes: String = "",
    val completedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)
