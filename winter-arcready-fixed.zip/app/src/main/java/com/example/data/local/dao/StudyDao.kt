package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.local.entity.StudyChapterEntity
import com.example.data.local.entity.StudyRevisionEntity
import com.example.data.local.entity.StudySessionEntity
import com.example.data.local.entity.StudySubjectEntity
import com.example.data.local.entity.StudyTopicEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface StudyDao {
    @Query("SELECT * FROM study_subjects ORDER BY id ASC")
    fun getAllSubjects(): Flow<List<StudySubjectEntity>>

    @Query("SELECT * FROM study_chapters WHERE subjectId = :subjectId ORDER BY orderIndex ASC")
    fun getChaptersForSubject(subjectId: Long): Flow<List<StudyChapterEntity>>

    @Query("SELECT * FROM study_topics WHERE chapterId = :chapterId ORDER BY id ASC")
    fun getTopicsForChapter(chapterId: Long): Flow<List<StudyTopicEntity>>

    @Query("SELECT * FROM study_sessions ORDER BY timestamp DESC")
    fun getAllStudySessions(): Flow<List<StudySessionEntity>>

    @Query("SELECT * FROM study_sessions WHERE date = :date")
    fun getStudySessionsForDate(date: String): Flow<List<StudySessionEntity>>

    @Query("SELECT * FROM study_revisions WHERE isCompleted = 0 ORDER BY scheduledDate ASC")
    fun getPendingRevisions(): Flow<List<StudyRevisionEntity>>

    @Query("SELECT * FROM study_revisions WHERE scheduledDate = :date ORDER BY id ASC")
    fun getRevisionsForDate(date: String): Flow<List<StudyRevisionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubject(subject: StudySubjectEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubjects(subjects: List<StudySubjectEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapter(chapter: StudyChapterEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChapters(chapters: List<StudyChapterEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopic(topic: StudyTopicEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopics(topics: List<StudyTopicEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: StudySessionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRevision(revision: StudyRevisionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRevisions(revisions: List<StudyRevisionEntity>)

    @Update
    suspend fun updateSubject(subject: StudySubjectEntity)

    @Update
    suspend fun updateChapter(chapter: StudyChapterEntity)

    @Update
    suspend fun updateTopic(topic: StudyTopicEntity)

    @Update
    suspend fun updateRevision(revision: StudyRevisionEntity)

    @Delete
    suspend fun deleteSubject(subject: StudySubjectEntity)

    @Delete
    suspend fun deleteChapter(chapter: StudyChapterEntity)

    @Delete
    suspend fun deleteTopic(topic: StudyTopicEntity)

    @Query("DELETE FROM study_subjects")
    suspend fun clearAllStudy()
}
