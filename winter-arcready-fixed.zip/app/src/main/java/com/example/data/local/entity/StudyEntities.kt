package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "study_subjects")
data class StudySubjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val colorHex: String = "#38BDF8",
    val targetHoursTotal: Int = 100,
    val completedHours: Float = 0f,
    val iconName: String = "menu_book"
)

@Entity(tableName = "study_chapters")
data class StudyChapterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val subjectId: Long,
    val title: String,
    val orderIndex: Int = 0,
    val isCompleted: Boolean = false
)

@Entity(tableName = "study_topics")
data class StudyTopicEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val chapterId: Long,
    val title: String,
    val plannedMinutes: Int = 90,
    val actualMinutes: Int = 0,
    val isCompleted: Boolean = false,
    val notes: String = "",
    val completedAt: Long? = null
)

@Entity(tableName = "study_sessions")
data class StudySessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val subjectName: String,
    val chapterTitle: String = "",
    val topicTitle: String = "",
    val durationMinutes: Int,
    val date: String, // YYYY-MM-DD
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = ""
)

@Entity(tableName = "study_revisions")
data class StudyRevisionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val subjectName: String,
    val topicTitle: String,
    val intervalDay: Int, // 1, 3, 7, 14, 30
    val scheduledDate: String, // YYYY-MM-DD
    val isCompleted: Boolean = false,
    val completedAt: Long? = null
)
