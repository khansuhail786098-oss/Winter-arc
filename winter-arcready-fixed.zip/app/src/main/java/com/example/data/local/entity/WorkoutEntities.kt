package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "workout_routines")
data class WorkoutRoutineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String, // e.g. "Push Day", "Pull Day", "Legs & Core"
    val description: String = "",
    val estimatedMinutes: Int = 60,
    val dayOfWeek: String = "Monday",
    val lastCompletedDate: String = "",
    val totalSessionsCompleted: Int = 0
)

@Entity(tableName = "exercises")
data class ExerciseEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val routineId: Long,
    val name: String,
    val targetSets: Int = 4,
    val targetReps: Int = 10,
    val targetWeightKg: Float = 0f,
    val restSeconds: Int = 90,
    val notes: String = "",
    val orderIndex: Int = 0
)

@Entity(tableName = "workout_sessions")
data class WorkoutSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val routineName: String,
    val durationMinutes: Int,
    val totalSets: Int,
    val totalReps: Int,
    val totalVolumeKg: Float,
    val date: String, // YYYY-MM-DD
    val completedAt: Long = System.currentTimeMillis(),
    val notes: String = ""
)
