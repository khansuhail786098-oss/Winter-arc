package com.example.data.local

import androidx.room.TypeConverter
import com.example.data.local.entity.TaskCategory
import com.example.data.local.entity.TaskPriority
import com.example.data.local.entity.TaskStatus

class Converters {
    @TypeConverter
    fun fromTaskCategory(category: TaskCategory?): String = category?.name ?: TaskCategory.OTHER.name

    @TypeConverter
    fun toTaskCategory(value: String?): TaskCategory = try {
        value?.let { TaskCategory.valueOf(it) } ?: TaskCategory.OTHER
    } catch (e: Exception) {
        TaskCategory.OTHER
    }

    @TypeConverter
    fun fromTaskPriority(priority: TaskPriority?): String = priority?.name ?: TaskPriority.NORMAL.name

    @TypeConverter
    fun toTaskPriority(value: String?): TaskPriority = try {
        value?.let { TaskPriority.valueOf(it) } ?: TaskPriority.NORMAL
    } catch (e: Exception) {
        TaskPriority.NORMAL
    }

    @TypeConverter
    fun fromTaskStatus(status: TaskStatus?): String = status?.name ?: TaskStatus.PLANNED.name

    @TypeConverter
    fun toTaskStatus(value: String?): TaskStatus = try {
        value?.let { TaskStatus.valueOf(it) } ?: TaskStatus.PLANNED
    } catch (e: Exception) {
        TaskStatus.PLANNED
    }
}
