package com.example.receiver

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.alarm.AlarmScheduler
import com.example.alarm.NotificationHelper
import com.example.data.local.WinterArcDatabase
import com.example.data.local.entity.TaskStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {
    companion object {
        private const val TAG = "AlarmReceiver"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent == null) return
        val action = intent.action ?: return

        val taskId = intent.getLongExtra("task_id", -1L)
        val taskTitle = intent.getStringExtra("task_title") ?: "Commitment Alarm"
        val taskCategory = intent.getStringExtra("task_category") ?: "DISCIPLINE"
        val isCritical = intent.getBooleanExtra("is_critical", false)
        val alarmStage = intent.getIntExtra("alarm_stage", 1)

        Log.d(TAG, "AlarmReceiver triggered with action: $action, taskId: $taskId")

        when (action) {
            "com.aistudio.winterarc.ACTION_TASK_ALARM" -> {
                NotificationHelper.showTaskAlarmNotification(
                    context = context,
                    taskId = taskId,
                    taskTitle = taskTitle,
                    taskCategory = taskCategory,
                    stage = alarmStage,
                    isCritical = isCritical
                )
            }
            "com.aistudio.winterarc.ACTION_SNOOZE_ALARM" -> {
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.cancel(taskId.toInt())
                AlarmScheduler.scheduleSnoozeAlarm(context, taskId, taskTitle, taskCategory, isCritical)
            }
            "com.aistudio.winterarc.ACTION_DISMISS_ALARM" -> {
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.cancel(taskId.toInt())
            }
            "com.aistudio.winterarc.ACTION_COMPLETE_TASK" -> {
                val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.cancel(taskId.toInt())
                if (taskId > 0) {
                    CoroutineScope(Dispatchers.IO).launch {
                        val db = WinterArcDatabase.getDatabase(context)
                        db.taskDao().updateTaskStatus(taskId, TaskStatus.COMPLETED, System.currentTimeMillis())
                    }
                }
            }
        }
    }
}
