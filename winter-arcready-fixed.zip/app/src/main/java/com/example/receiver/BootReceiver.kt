package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.alarm.AlarmScheduler
import com.example.data.local.WinterArcDatabase
import com.example.domain.DateUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    companion object {
        private const val TAG = "BootReceiver"
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == "android.intent.action.QUICKBOOT_POWERON" ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED
        ) {
            Log.d(TAG, "Restoring alarms after event: $action")
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = WinterArcDatabase.getDatabase(context)
                    val today = DateUtils.todayString()
                    val tasks = db.taskDao().getScheduledAlarmTasks(today)
                    tasks.forEach { task ->
                        AlarmScheduler.scheduleTaskAlarm(context, task)
                    }
                    Log.d(TAG, "Restored ${tasks.size} alarms successfully.")
                } catch (e: Exception) {
                    Log.e(TAG, "Error restoring alarms: ${e.message}")
                }
            }
        }
    }
}
